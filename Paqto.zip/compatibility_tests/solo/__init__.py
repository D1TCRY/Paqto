"""Single-runtime compatibility checks."""

