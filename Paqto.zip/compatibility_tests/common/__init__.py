"""Shared compatibility-suite helpers."""

