# Independent portability audit

Date: 2026-08-18

## Verdict

Paqto is **SUPPORTED & TESTED only on the exact Windows 11 / CPython 3.14.6
runtime used by this audit**, for the capabilities exercised below. The
verified scope includes the default Windows Proactor event loop, TCP over IPv4
and IPv6 loopback, IPv4 UDP broadcast, TLS, mTLS, custom in-memory CA trust,
caller-injected `SSLContext` objects, strict certificate-to-peer identity,
explicit-endpoint operation without discovery, ACK, request/reply, reconnect,
network refresh, cancellation, and repeated lifecycle cleanup.

The reviewed architecture remains a reasonable cross-platform expectation, but
Linux, macOS, other Python versions, Android, real multi-interface networks,
and physical isolated-LAN behavior are not converted into tested claims by
static analysis or CI configuration. No Android Python runtime was executed.

Release recommendation: acceptable as a pre-alpha controlled-LAN release for
the exact tested Windows runtime. Do not make a blanket cross-platform or
Android `SUPPORTED & TESTED` claim until the retained real-runtime evidence in
the blockers section exists.

## Audit scope and method

The audit did not trust the previous implementation or its reports. It read the
complete current contents of `pyproject.toml`, `README.md`, `src/paqto`, every
test, example, tool, CI workflow, public documentation page, all development
logs in chronological order, Git history, initial/final `git status`, and the
complete working-tree diff. Generated build output was not treated as source.

The working tree was already extensively dirty at audit start, including
tracked source/documentation/test edits and untracked CI, conformance, tooling,
and portability files. Those changes were treated as untrusted input and were
not reset, staged, committed, or pushed. Build-generated tracked metadata was
restored to its exact pre-audit content; root-level temporary audit files were
removed after their retained reports were written under this log.

Static searches covered platform-name branching, path assumptions, native
OS APIs, signals, descriptors, event-loop policy, asyncio calls, subprocesses,
multiprocessing, socket options, errno handling, interface names, temporary
paths, drive letters, separators, external hosts, IP-family assumptions, trust
stores, certificate provisioning, DNS, and interface cardinality.

## Findings by severity

### Critical

None found.

### High

None found.

### Medium

1. **Discovery-free operation required a host-defined no-op adapter.** TCP/TLS
   communication through an explicit `DiscoveredPeer` worked, but
   `PaqtoNode.discovery` was mandatory and both conformance and interoperability
   tools duplicated a private null implementation. This was an avoidable host
   burden on runtimes where UDP discovery is unavailable. Fixed by adding the
   public restartable `NoDiscovery`, using it when `discovery` is omitted or
   `None`, converting the tools to that public API, documenting the direct
   endpoint path, and adding start/stop/start regression coverage.

2. **The IPv6 conformance result could be a false positive.** The old check
   proved only raw standard-library TCP/UDP binds and did not execute the Paqto
   TCP adapter. Fixed by requiring a public `LanTransport` IPv6 listener,
   bracketed endpoint, client connection, framed exchange, and clean close
   after the capability preflight. The corrected check passed on this Windows
   host.

### Low

1. **The two-device explicit endpoint builder mishandled IPv6 literals.** It
   concatenated `tcp://HOST:PORT`, yielding an ambiguous address for a literal
   such as `::1`. Fixed by exporting and using `endpoint_from_host_port()` and
   adding a regression test for `tcp://[::1]:PORT`.

2. **Desktop CI did not run `pip check`.** The local audit command passed, and
   the workflow now has the same dependency-consistency gate. The workflow
   edit is configuration evidence only; its hosted jobs were not executed in
   this workspace.

## Independently verified existing portability behavior

- Runtime code has no `os.name`, `sys.platform`, platform-name, POSIX, Win32,
  signal, subprocess, multiprocessing, raw file-descriptor, hardcoded `/tmp`,
  drive-letter, or event-loop-policy branch.
- The only socket-option capability branch uses `hasattr(socket,
  "SO_REUSEPORT")` and tolerates refusal. `LanDiscovery` is explicitly and
  honestly IPv4-broadcast-only; the generic core has no socket family.
- `PaqtoNode` never calls `asyncio.run()` and does not require a user-selected
  loop policy. Actual execution used the Windows default
  `asyncio.windows_events.ProactorEventLoop`.
- Wildcard address selection never opens an Internet probe. Hostname resolution
  is best effort and family-matched; an explicit `advertised_host` bypasses it.
- No runtime host such as `8.8.8.8`, public DNS name, HTTP endpoint, or external
  service exists. The conformance and two-process runs used only loopback/local
  broadcast and bundled public test certificates.
- TLS supports file-based credentials, file or in-memory custom CA data,
  mTLS, strict identity resolution, and caller-prepared client/server
  `SSLContext` injection. Tests use their custom CA and do not depend on the
  machine trust store. Runtime code creates no temporary secret file.
- `start()`, `stop()`, a later `start()`, idempotent stop, cancellation-shielded
  cleanup, `network_changed()`, explicit advertised addresses, fresh TLS/READY
  handshakes, and reconnection were executed successfully.
- No references to mobile or UI frameworks were found anywhere in the
  repository. Runtime code contains no manifest, runtime-permission, activity,
  foreground-service, background-policy, SDK, or mobile lifecycle integration.
  Those boundaries remain the host application's responsibility.
- The conformance report has stable schema/status fields, retains individual
  results, distinguishes `PASS`, `FAIL`, `SKIP`, and `UNAVAILABLE`, exits `2`
  for required unavailability, and uses public Paqto APIs for adapter behavior.
  Direct socket binds are capability preflights only. The two-device tool has no
  platform-specific code.

## Changes made by this audit

- Added and exported `NoDiscovery`; made `PaqtoNode.discovery` optional.
- Exported the portable LAN endpoint constructor and used it in the two-device
  tool.
- Strengthened IPv6 conformance from raw capability probing to an actual Paqto
  adapter exchange.
- Added regression tests for default discovery-free lifecycle and IPv6 literal
  endpoint formatting.
- Added the CI `pip check` gate.
- Documented exact Paqto responsibility, host responsibility, discovery-free
  operation, Android evidence rules, and the stricter IPv6 conformance meaning.

## Real commands and results

All execution in this section happened on **real Windows**, not emulation:

- Host: Windows 11, build `10.0.26200`, AMD64.
- Interpreter: CPython 3.14.6.
- Event loop: default `asyncio.windows_events.ProactorEventLoop`; no policy
  change was made.
- `python -X dev -m pytest -q -W error`: **180 passed**.
- `python -m ruff check src tests examples platform_conformance tools`:
  **passed**.
- `python -m mypy src platform_conformance tools`: **passed, 33 source files**.
- `python -m compileall -q src tests examples platform_conformance tools`:
  **passed**.
- `python -m pip check`: **no broken requirements**.
- `python -m build`: **passed**, producing the sdist and universal wheel.
- Isolated wheel import: **passed**; `NoDiscovery` and the bracketed IPv6 helper
  were present, and conformance code was absent from the runtime wheel.
- `python examples/lan_two_nodes.py`: **passed**, message delivered.
- Full conformance: **14 PASS, 0 FAIL, 0 SKIP, 0 UNAVAILABLE**. Retained report:
  `2026-08-18_14-portability-audit-conformance-windows-py314.json`.
- CI conformance profile: **13 PASS, 0 FAIL, 1 deliberate broadcast SKIP,
  0 UNAVAILABLE**. Retained report:
  `2026-08-18_14-portability-audit-conformance-ci-windows-py314.json`.
- Networking/concurrency/lifecycle integration subset: **10 consecutive
  passing runs** with Python development mode and warnings as errors.
- `LanDiscovery` tests: **20 consecutive passing runs**, including repeated
  UDP lifecycle work.
- Full conformance, including real local broadcast: **5 consecutive passing
  runs** after the fixes.
- Two independent Python processes, explicit IPv4 endpoint, discovery disabled,
  mTLS, strict SAN URI identity, READY handshake, ACK, request/reply, disconnect,
  fresh reconnect, second request/reply, and cleanup: **client PASS and server
  PASS**. Retained per-process JSON reports:
  `2026-08-18_14-portability-audit-two-process-client.json` and
  `2026-08-18_14-portability-audit-two-process-server.json`.
- `git diff --check`: **exit 0**. Git emitted only LF-to-CRLF conversion
  warnings; no whitespace error was found.

The initial sandboxed build attempt was denied access to its own temporary
build directory. The exact standard isolated `python -m build` was then run
with permission outside that sandbox boundary and succeeded. This environmental
denial is not reported as a Paqto build failure.

## Network-isolated assessment

The source and tests contain no Internet host or HTTP dependency. Explicit
numeric endpoints bypass Paqto's best-effort hostname advertisement lookup, and
`NoDiscovery` creates no UDP socket or name/interface lookup. Local conformance
and the two-process mTLS scenario completed without an Internet request, public
DNS, or machine trust-store dependency.

This host was not physically disconnected from every network, so the result is
evidence that Internet access is unnecessary, not a physical no-route hardware
certification. A retained run on an isolated LAN with no default route and DNS
disabled remains required for that stronger deployment claim.

## Responsibility boundary

### Paqto responsibility

- networking through configured adapters;
- protocol negotiation, framing, correlation, ACKs, limits, and routing;
- encryption and identity information according to supplied TLS configuration;
- peer communication and restartable lifecycle of Paqto-owned resources;
- cleanup, reconnect, and host-triggered network refresh.

### Host responsibility

- provide and maintain the Python runtime and event loop;
- obtain OS network permissions and configure firewall/network policy;
- own process/application creation, recreation, foreground/background policy,
  suspension, and shutdown;
- supply reachable addresses, endpoints, credentials, trust policy, and Paqto
  configuration;
- notify Paqto of network changes or stop/start it around suspension;
- implement application authorization, durable state, idempotency, retry, and
  success semantics.

Paqto does not manage manifests, permission prompts, application components,
foreground execution facilities, mobile background policy, or platform SDK
APIs.

## Real support matrix

| Platform/runtime | Status | Evidence |
| --- | --- | --- |
| Windows 11 / CPython 3.14.6 / AMD64 | **SUPPORTED & TESTED** | Full local conformance 14/14, 180 tests, stress, build, and two-process mTLS explicit-endpoint run on the real host. |
| Windows / CPython 3.10, 3.12 or other versions | **EXPECTED / AWAITING CI** | Workflow configured; not executed here. |
| Linux / CPython 3.10, 3.12, 3.14 | **EXPECTED / AWAITING CI** | Static review and workflow configuration only. |
| macOS / CPython 3.10, 3.12, 3.14 | **EXPECTED / AWAITING CI** | Static review and workflow configuration only. |
| Android / compatible Python 3.10+ | **EXPECTED / AWAITING DEVICE VALIDATION** | Host boundary and API reviewed; no Python process was run on Android. |

## Residual limitations and blockers

- Android remains untested. A real device/emulator Python run of the full suite
  and two-device exercise is a blocker for an Android supported claim.
- Hosted Linux/macOS/Windows-version jobs have not produced retained reports in
  this workspace. CI configuration is not execution evidence.
- `LanDiscovery` requires IPv4 UDP broadcast. It is optional; deployments that
  cannot use it must provision endpoints or supply another adapter.
- Actual IPv6-only, dual-stack, multi-interface, link-local/scoped-address,
  suspend/resume, firewall, and address-churn environments remain untested.
- Paqto publishes one listener endpoint. Multi-interface deployments must
  choose an appropriate advertised address; plural advertisement is future API
  work.
- Automatic wildcard advertisement may consult local hostname resolution and
  is topology-dependent. Use explicit `advertised_host` and explicit endpoints
  where DNS is absent or ambiguous.
- System trust-store variation was not certified. Tests deliberately use a
  custom CA or injected contexts. The host owns trust and credential storage.
- Real slow/lossy network behavior, TLS backend differences, and abrupt radio
  loss need target-environment testing despite deterministic cancellation and
  reconnect coverage.
- A blanket statement that every Python version `>=3.10` and every operating
  system is supported is blocked by missing retained real-runtime evidence.

No commit and no push were performed.
