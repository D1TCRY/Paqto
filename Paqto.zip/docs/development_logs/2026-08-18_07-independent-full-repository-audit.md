# Independent full-repository audit

Date: 2026-08-18  
Scope: complete Paqto repository after the async/security/protocol architecture work  
Auditor: independent Codex pass; prior implementations were treated as untrusted until inspected and tested

## Verdict

Paqto now has a coherent generic, async-first architecture and a materially
stronger failure boundary than the state found at the beginning of this audit.
No domain-specific restaurant, table, order, payment, or printer concepts were
found in the framework. The final suite, static checks, example, sdist, and
wheel all pass.

The code is suitable for controlled-LAN evaluation and integration testing. It
is not yet a general hostile-network production release. The remaining limits
are explicit: discovery is unauthenticated, plain TCP is still the default,
TLS admission happens before the node connection cap, queues have count but no
aggregate byte budgets, serializer safety belongs to the deployment, and there
is no authorization, durability, retransmission, or exactly-once processing.

## Material reviewed

The audit read the repository as a whole, not only the latest diff:

- `README.md`, `pyproject.toml`, license, package metadata, and `.gitignore`;
- every module under `src/paqto`, including the removed threaded implementation
  from `HEAD` for API/migration comparison;
- all tests under `tests`, certificate-fixture documentation, and certificate
  metadata (the fixture private keys are public test material only);
- `examples/lan_two_nodes.py`;
- every document under `docs`;
- all development logs, reconstructed chronologically in this order:
  `2026-05-17-lan-tcp-transport.md`, `2026-05-17_lan-discovery.md`,
  `2026-05-17_lan-test-coverage.md`, then `2026-08-18_01` through
  `2026-08-18_06`;
- the complete working-tree status and diff against `HEAD`.

The worktree was already extensively modified before the audit. Those changes
were preserved. No commit and no push were performed.

## Reconstructed architecture

### Core contracts

- `Peer` is the logical identity; `Endpoint` is a transport-specific address.
- `DiscoveryService` yields timestamped `DiscoveredPeer` reachability hints.
- `Transport` creates framed `Connection` objects and a `Listener`.
- `Serializer` owns only application `Message` envelope encoding.
- `ConnectionManager` owns the canonical connection and single-flight connect
  state per peer.
- `PaqtoNode` owns protocol negotiation, canonical-session selection, routing,
  request/reply, ACKs, heartbeat, reconnect, bounded work queues, events, and
  coordinated lifecycle.

### Session establishment

The real session path is:

`transport connection -> optional TLS/mTLS -> PAQTO hello -> READY -> frames`

The hello requires exact protocol-version and serializer-id equality. There is
no automatic version downgrade. The negotiated message size is the minimum of
the two offers and capabilities are the ordered intersection. An outgoing
session must match the intended discovery peer id. If a transport exposes an
authenticated id, it must also match the hello. Strict deployments can require
that binding for every READY session.

### Messaging and concurrency

Application frames and control frames have distinct markers. One reader task
per physical connection parses protocol controls and enqueues application
work. A fixed worker pool runs handlers so handlers do not execute inside the
reader task. One writer task and bounded queue exist per READY connection.
Request, ACK, and heartbeat futures are tied to the exact connection and are
removed on success, timeout, cancellation, disconnect, and stop. Simultaneous
opposite-direction connections are resolved deterministically from peer ids.

### LAN implementation

LAN discovery uses IPv4 UDP broadcast and is explicitly untrusted. LAN
transport uses length-prefixed TCP frames, optionally protected by TLS 1.2+.
Server certificate and hostname verification default on when TLS is enabled;
mTLS is opt-in. A certificate-to-`Peer.id` resolver is deliberately supplied
by the application because Paqto defines no X.509 naming convention.

## Findings and disposition

### Critical

None found.

### High

#### H-01 — remote discovery-cache memory exhaustion — fixed

`LanDiscovery` accepted an unbounded number of unique announced peer ids. The
node also retained expired ids in `_known_peers` plus a monotonic expired-id
set. A UDP sender could therefore grow memory indefinitely.

Fix: `max_discovered_peers` now defaults to 1024; expired discovery entries are
pruned before admission; existing entries can still refresh at capacity; node
cache entries are deleted on expiry and the monotonic id set was removed.
Regression tests cover admission, refresh-at-capacity, validation, and expiry.

#### H-02 — incomplete declared frame could retain buffers indefinitely — fixed

After sending a legal four-byte length header, a peer could leave the payload
partial indefinitely when core `idle_timeout` was disabled. That retained a
connection slot and up to the configured frame buffer.

Fix: LAN connections now apply configurable `frame_payload_timeout`, 30 seconds
by default, after a length is declared. Timeout closes the connection. A test
sends a partial payload and verifies timeout plus EOF.

#### H-03 — unbounded TCP pre-accept queue — fixed

`TcpListener` could accumulate an unbounded deque of established connections
before `PaqtoNode.max_connections` admission ran.

Fix: `max_pending_accepts` defaults to 128. Excess established connections are
closed immediately. Tests cover saturation and invalid configuration.

#### H-R01 — default/plain deployments permit peer impersonation — residual, documented

UDP discovery can be spoofed. Plain TCP plus a self-declared hello cannot prove
who owns a `Peer.id`; an active attacker can advertise or directly claim an id.
Discovery/hello mismatch is rejected, but an attacker controlling both claims
can remain consistent. This is a property of the non-authenticated profile,
not a cryptographic identity solution.

Required production profile: verified TLS, mTLS where both directions require
peer proof, an identity resolver, `require_authenticated_peer_id_match=True`,
authorization, and network-level access controls. README now states this
without implying that discovery is trusted.

### Medium

#### M-01 — connection-manager cleanup could poison a peer permanently — fixed

A failing `Connection.close()` during failed preparation could mask the primary
error and leave the same-peer `_in_flight` entry installed. `close_peer()` could
also leave CLOSING state behind after a close error.

Fix: cleanup now unconditionally releases single-flight/state bookkeeping while
preserving the primary exception. Regression tests use connections whose close
method fails.

#### M-02 — transport/listener/discovery lifecycle races and cancellation leaks — fixed

- An outgoing LAN connect could complete after `stop()` and return an untracked
  live connection.
- `TcpListener.start()` racing `close()` could publish a server after close.
- cancelling `LanDiscovery.start()` while its datagram endpoint was being
  created could leak the socket and local state.

Fix: LAN transport uses a lifecycle generation; listener and discovery start/
stop paths are serialized; discovery catches cancellation for rollback. Tests
cover all three races.

#### M-03 — TLS handshake resource window had the asyncio long default — fixed

TLS handshakes occur before the Paqto node can apply its connection count. A
slow TCP client could retain handshake resources for the asyncio default.

Fix: `TlsConfig.handshake_timeout` is finite, validated, defaults to 10 seconds,
and is applied to incoming and outgoing TLS. Regression tests cover a raw slow
client, invalid values, an untrusted server certificate, a missing client
certificate, hostname mismatch, and valid mTLS.

Residual: there is still no global pre-TLS concurrency/rate limiter. OS and
network controls remain required for hostile connection floods.

#### M-04 — ambiguous/pathological JSON control and discovery data — fixed

Control/discovery JSON accepted duplicate object keys, non-standard non-finite
numbers, and data that could be pathologically nested. Extremely large integer
tokens could also escape normalization differently across Python versions.
Duplicate identity/version keys are especially unsafe across implementations
that choose different first/last-key semantics.

Fix: duplicate keys are rejected; non-finite and oversized integers are
rejected; nesting is capped at 32; recursion and integer parser failures are
normalized; local encoders use `allow_nan=False`; control size remains capped
at 64 KiB. Tests cover deep data, duplicate fields, huge integers, and NaN.

#### M-05 — documented application limit did not fit the default LAN frame — fixed

The default application limit was 16 MiB and the default transport frame was
also 16 MiB, but Paqto adds a one-byte marker. A message exactly at the
negotiated default maximum therefore failed at the transport boundary.

Fix: the default LAN frame is application maximum plus one byte. Exact-limit
and over-limit behavior is covered.

#### M-06 — accept-loop adapter error silently stopped inbound service — fixed

One transient/custom-listener exception terminated the accept task while the
node continued reporting itself as running.

Fix: transient adapter errors emit `TRANSPORT_ERROR`, log sanitized error type,
and retry after a short delay. Cancellation and terminal listener closure keep
their distinct behavior. Regression test verifies recovery.

#### M-07 — supported Python 3.10 could not import events — fixed

`events.py` imported `datetime.UTC`, introduced in Python 3.11, while package
metadata promises Python 3.10.

Fix: use `timezone.utc`. All 27 source files also parse with Python 3.10 grammar.
The installed interpreter for this audit was Python 3.14.6, so a real 3.10
runtime CI job is still required.

#### M-R01 — no aggregate byte/memory budget — residual, documented

Queue sizes and pending maps are count-bounded, but inbound/outbound queues do
not enforce byte quotas. At permissive defaults, many maximum-size messages can
still consume substantial memory. A serializer can also expand a small input
into a large Python object. Applications using WAIT can create arbitrarily many
caller tasks waiting outside the queue.

README now states these boundaries. Production deployments must jointly reduce
message, queue, pending-operation, and connection limits and must bound their
own task creation. A future release should add optional byte budgets/metrics.

#### M-R02 — shutdown depends on cooperative adapters — residual

Node task ownership and normal cancellation cleanup are strong, but a custom
adapter whose `close()`/`stop()` never returns can still hang shutdown, and
cancelling the outer `stop()` operation is not a hard guaranteed cleanup
protocol. A future API should define adapter close deadlines and a
cancellation-resilient shutdown contract.

### Low

#### L-01 — message identity field shapes were not validated early enough — fixed

Incoming sender/recipient values from a custom serializer were compared before
strict shape validation. They are now required to be non-empty strings or
`None`, and incoming envelopes are validated before session identity checks.

#### L-02 — README overclaimed backpressure and ACK implications — fixed

The old wording could imply that a bounded queue bounded caller-created tasks,
and it did not explicitly say an ACK may precede dispatch admission. README now
distinguishes queue storage, waiting tasks, transport writes, Paqto receipt
ACKs, and application success.

#### L-03 — migration behavior was easy to misread — fixed/documented

`paqto.connection` preserves the import path for the new abstract async type,
but does not emulate the retired threaded constructor or blocking methods. The
module docstring and README now say so explicitly.

## Security review result

- Certificate-chain verification: enabled by default whenever TLS is enabled;
  untrusted-server regression test passes.
- Hostname verification: enabled by default; mismatch regression test passes.
- mTLS: supported and tested for success and missing client proof.
- Insecure TLS: requires explicit `verify_peer=False` plus
  `check_hostname=False`; no implicit downgrade was found.
- Protocol downgrade: exact v1 equality; mismatch closes the session.
- Identity binding: authenticated transport id, expected discovery id, hello
  id, message sender, and recipient are checked at their respective boundaries.
- Discovery impersonation: still possible because UDP announcements are
  intentionally unauthenticated; strict TLS identity binding prevents that hint
  from becoming authenticated identity.
- Secrets/logs: no payload, headers, certificate bodies, private keys, or
  exception text are logged by Paqto by default. Peer/message identifiers are
  metadata and may still be sensitive.
- Malformed/oversized input: TCP frames, application messages, controls,
  discovery datagrams, JSON depth/numbers/duplicates, and handshake fields are
  bounded or rejected.
- Resource exhaustion: peer cache, pending accepts, node connections, pending
  requests/ACKs, queues, handler workers, and partial frame payload duration are
  bounded. Aggregate bytes, TLS pre-admission concurrency, and serializer
  expansion remain deployment concerns.

## Concurrency review result

The inspected/tested paths cover same-peer single-flight connect, concurrent
different-peer connects, simultaneous bidirectional sessions, deterministic
duplicate resolution, request/ACK future cleanup, late and wrong-connection
replies, abrupt disconnect, reconnect/stop interaction, heartbeat/close,
connection manager close failure, repeated start/stop, listener start/close,
discovery-start cancellation, and shutdown under load. Future completion sites
check `done()` before resolving, and correlations are removed before or during
terminal resolution so duplicate controls cannot resolve one Future twice.

No reproducible deadlock or orphaned node task remained in the final runs.
Sync handlers can still block the event loop by application choice; README
requires them to return quickly.

## Protocol guarantees

Paqto v1 currently guarantees only:

- a framed READY session after exact protocol and serializer matching;
- negotiated maximum serialized message size and capability intersection;
- consistency of message sender/recipient with the selected READY session;
- optional authenticated transport identity to logical-peer binding;
- in-memory routing and exact-connection request/reply correlation;
- optional ACK meaning remote receipt, deserialization, and envelope validation;
- optional heartbeat liveness and session-only reconnect;
- FIFO handoff from Paqto's per-connection writer queue to that transport.

Paqto does not guarantee transport delivery after a local write, at-least-once,
exactly-once, deduplication, persistence, durable queues, transactional
delivery, global ordering, automatic resend, authorization, or application
success. A send timeout/cancellation does not prove the queued frame was never
transmitted. Events are best-effort diagnostics and can be dropped.

## API and compatibility review

The public exports and error hierarchy are internally consistent. Specific
errors subclass the relevant protocol/request/timeout roots. The audit added
only configurable hardening controls and one event enum member:

- `LanDiscovery(max_discovered_peers=1024)`;
- `LanTransport(max_pending_accepts=128, frame_payload_timeout=30.0)`;
- `TlsConfig(handshake_timeout=10.0)`;
- `NodeEventType.TRANSPORT_ERROR`.

Behavioral compatibility notes:

- the default LAN maximum frame increased by one byte to honor the existing
  application-size contract;
- incomplete declared LAN frame payloads now close after 30 seconds by default;
  `None` restores the old unbounded wait, but is discouraged;
- discovery and pending-accept admission are now finite by default;
- the broader architectural branch already contains a deliberate breaking
  replacement of the old threaded `Connection(host, port)` API with abstract
  async `Connection`/`Transport`/`Listener` contracts.

Because the project is classified pre-alpha, this migration is defensible but
must not be released silently under an apparently compatible version.

## Tests added or strengthened

Regression/adversarial coverage now includes:

- failed connection preparation when close also fails;
- `close_peer()` state cleanup after close failure;
- deep, duplicate-key, huge-integer, non-finite, and malformed control JSON;
- deep/duplicate discovery JSON and bounded spoofed-id admission;
- expired node/discovery cache removal;
- strict sender/recipient envelope shapes;
- exact default frame boundary, over-limit frame, abrupt truncation, and
  incomplete-payload timeout;
- unbounded pre-accept flood prevention;
- TLS invalid CA, hostname mismatch, valid mTLS, missing client certificate,
  identity mismatch, and slow handshake timeout;
- discovery/hello/authenticated-identity mismatch;
- connect completion racing transport stop;
- listener start racing close and cancelled discovery start;
- transient accept failure recovery;
- request cancellation, timeout, late reply, and wrong-connection reply;
- simultaneous connections, reconnect, heartbeat timeout, inbound/outbound
  queue saturation, pending-map limits, shutdown under load, and repeated
  start/stop.

## Commands and results

Representative commands executed from the repository root:

```text
git status --short --branch
git diff --stat
git diff --check
python -X dev -m pytest -q -W error
python -m mypy src
python -m ruff check src tests examples
python -m compileall -q src examples
python -m pip check
python examples/lan_two_nodes.py
python -m build
```

Results:

- initial full suite before audit fixes: 124 passed;
- final full suite: 148 passed in approximately 2.4 seconds;
- final full suite repeated three times: 148/148/148 passed;
- concurrency, hardening, request/reply, and TLS subset repeated ten times:
  45 passed on every run (450 passing test executions);
- mypy: no issues in 27 source files;
- Ruff: all checks passed. Two `PYI034` recommendations were explicitly
  suppressed at the two context-manager methods because `typing.Self` is not
  part of the declared Python 3.10 baseline;
- compileall: passed;
- dependency consistency (`pip check`): no broken requirements;
- Python 3.10 grammar parse: all 27 source files passed;
- runnable LAN example: passed and delivered its message;
- isolated sdist/wheel build: succeeded, producing
  `paqto-0.0.1.tar.gz` and `paqto-0.0.1-py3-none-any.whl`;
- wheel inspection: 32 entries, metadata `paqto` version `0.0.1`,
  `Requires-Python: >=3.10`, and all new protocol/security modules included.

The first isolated/non-isolated build attempts inside the restricted sandbox
failed because temporary virtual-environment/build directories were denied and
the host environment lacked setuptools. The final approved isolated build
completed successfully; this was an environment failure, not a package build
failure. The audit-created temporary directory was removed afterwards.

No test, static-analysis, example, or build failure remains at the end of the
audit. `git diff --check` is clean; Git only reports the existing LF-to-CRLF
working-tree warnings on Windows.

## Residual technical debt

1. Add an authenticated discovery option or signed announcement profile;
   bounded unauthenticated discovery can still be poisoned for availability.
2. Add pre-TLS connection concurrency/rate limits or document a supported
   reverse-proxy/firewall profile.
3. Add optional aggregate byte budgets and queue memory metrics.
4. Define shutdown deadlines and cancellation semantics for third-party
   `Transport`, `Listener`, `DiscoveryService`, and `Connection` adapters.
5. Add property/fuzz testing for frame/control/serializer boundaries and
   cross-language Paqto v1 test vectors.
6. Run real CI on Python 3.10 through 3.14, Linux/macOS/Windows, IPv4/IPv6, and
   repeated slow-network/fault-injection scenarios.
7. Specify certificate naming, revocation, rotation, pinning, and application
   authorization profiles outside the generic core.
8. Decide whether event drops need metrics or a separate reliable audit sink;
   current events are intentionally best effort.
9. Publish a formal protocol document before independent implementations rely
   on the current JSON/control details.

## Release recommendation

Do not present `0.0.1` as production ready. If this architecture has not been
released, publish it first as `0.1.0a1` (or another explicit pre-release) after
the multi-version CI matrix passes. If the old threaded API has already been
released to users, treat the async replacement as a documented breaking line,
provide a migration guide, and choose the version according to the project's
declared compatibility policy rather than silently reusing `0.0.1`.

Before a production-stability claim, require: strict TLS/mTLS identity tests in
CI, network flood controls, safe serializer review, byte/memory-budget work,
formal Paqto v1 vectors, and a supported authorization/certificate lifecycle
profile.
