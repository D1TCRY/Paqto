# Request/Reply Correlation and Technical Acknowledgements

## Phase objective

Add generic, in-memory request/reply correlation using the existing
`Message.id` and `Message.reply_to` fields, plus an optional Paqto technical ACK
integrated with the protocol control-frame layer. The work remains transport-
agnostic and domain-agnostic and does not add persistence, retries, application
transactions, or proprietary cryptography.

## Initial state

- The uncommitted worktree produced by the previous foundation, TLS, and
  protocol-handshake phases was treated as the source of truth.
- The latest three phase logs were reread, with particular attention to
  `2026-08-18_03-protocol-handshake.md`.
- Git status showed the prior phase changes and the pre-existing user change to
  `.gitignore`. No unrelated user change was overwritten.
- `docs/development_logs/` remains ignored by the existing
  `.gitignore:2:docs/development_logs/` rule. No previous log or Git policy was
  changed.
- Baseline: `python -m pytest -q` passed with `67 passed in 0.57s`.
- The protocol layer already separated READY application frames (`0x01`) from
  control frames (`0x00`), but rejected every post-handshake control frame.
- `Message.id` and `Message.reply_to` already existed but were not used by
  `PaqtoNode`.

## Files analyzed

The phase reread the current README, public exports, configuration, errors,
`Message`, `PaqtoNode`, `MessageRouter`, `ConnectionManager`, serializer,
protocol framing/handshake, LAN/TLS integration tests, node lifecycle tests,
protocol tests, the example, and all pertinent development logs. The real
connection/session cleanup paths and TLS-authenticated session binding were
reviewed before correlation state was introduced.

## Public API introduced

### Request/reply

```python
response = await node.request(
    peer,
    payload,
    type="query",
    timeout=5,
)

await node.reply(message, response_payload, type="query-result")
```

`request()` returns the complete correlated response `Message`. `reply()` sets
`reply_to` to the original `Message.id`, preserves generic type/payload/headers,
and normally uses the exact READY connection on which the handler received the
request. Outside a handler it can use a unique READY connection for that peer;
it rejects ambiguous duplicate-session routing.

Both `send()`, `request()`, and `reply()` accept `require_ack` and
`acknowledgement_timeout`. `PaqtoConfig` adds:

- `request_timeout` (default 10 seconds);
- `acknowledgement_timeout` (default 10 seconds);
- `enable_acknowledgements` (default true).

Read-only `pending_request_count` and `pending_acknowledgement_count` expose
correlation state for diagnostics and tests. New public exceptions are
`RequestError`, `RequestTimeoutError`, `AcknowledgementError`,
`AcknowledgementTimeoutError`, and `AcknowledgementUnavailableError`.

## Correlation lifecycle

Each outgoing request creates a unique normal `Message` and an asyncio Future
indexed by that message id. The pending entry records both the intended session
peer id and the exact connection. It is inserted before `send_frame()` is
awaited, closing the reply-before-registration race.

An incoming message with non-null `reply_to` is correlation traffic, not a new
application request. It completes a pending Future only when all of these hold:

- `reply_to` names a currently pending request;
- it arrived on the same connection;
- the READY session peer matches the pending peer.

Unknown, malformed, late, duplicate, wrong-peer, and wrong-connection replies
cannot complete another request. Well-formed unknown/late replies are consumed
without application dispatch. Pending entries are removed in `finally` blocks
after success, timeout, caller cancellation, serialization/send failure, ACK
failure, connection loss, or node shutdown.

Connection reader cleanup fails only entries belonging to that connection.
`PaqtoNode.stop()` fails and clears every remaining request and ACK before
closing sessions. Future exceptions are explicitly observed to prevent
unretrieved-Future warnings in cancellation races.

## Handler and reader lifecycle decision

The connection reader no longer awaits application handlers inline. It validates
and classifies each message, sends any negotiated technical ACK, resolves
replies, and schedules ordinary application dispatch in a node-supervised task.
This is necessary so an async handler may reply with ACK or start nested
request/reply work without blocking the only task able to receive the resulting
control/reply frame.

`stop()` cancels and gathers handler tasks as well as reader tasks, excluding the
current task so calling `stop()` from a handler cannot await itself. Different
messages may now have concurrently running handler invocations. For one message,
the `MessageRouter` still invokes its registered handlers in order.

## Technical ACK design and semantics

The reserved capability `paqto.ack.v1` is included in the hello when ACK support
is enabled and must be negotiated by both peers. An ACK is a small JSON Paqto
control frame containing protocol magic, type `ack`, and the accepted
application `message_id`. It is parsed before the serializer/router boundary and
never reaches application handlers.

The receiving node emits an ACK only after:

1. the frame is recognized as application data;
2. the negotiated size limit is satisfied;
3. deserialization yields a `Message`;
4. sender, recipient, `id`, and `reply_to` envelope validation succeeds.

The ACK is sent before application dispatch. Therefore it means only:

> the remote Paqto protocol reader received and accepted the message envelope.

It explicitly does **not** mean:

- an application handler ran or completed;
- an application operation succeeded;
- state was committed or made durable;
- a transaction completed;
- the peer will not crash immediately afterward;
- the message will not be delivered or processed more than once.

Waiting for an ACK is explicit with `require_ack=True`. If support was not
negotiated, the send fails before application bytes are emitted. Unknown,
duplicate, or late ACK ids are safely ignored. Malformed or unexpected control
frames remain protocol errors and close the affected connection.

## Guarantees offered

- In-memory correlation by exact `Message.id` / `reply_to`.
- Registration before send and event-loop-safe handling of simultaneous
  independent requests.
- Peer and connection scoping for reply and ACK completion.
- Deterministic cleanup on every normal and tested failure path.
- Specific timeout and feature-unavailable exceptions.
- Control ACK frames never reach application handlers.
- Existing transport security and handshake identity checks remain in force.

## Guarantees explicitly not offered

- No exactly-once, at-least-once, or durable-delivery promise.
- No retransmission, retry, reconnect, durable queue, persistence, or session
  resumption.
- No technical deduplication cache was added. Consequently there is no hidden
  TTL, memory scope, or limit to describe, and applications must implement any
  domain idempotency they require.
- No application completion/result semantics are attached to ACK.
- No authorization semantics are attached to request/reply.
- On an unauthenticated transport, session peer ids remain protocol claims, not
  cryptographic identity proof.

## Files modified in this phase

Runtime/API:

- `src/paqto/core/protocol.py`
- `src/paqto/core/node.py`
- `src/paqto/core/config.py`
- `src/paqto/core/errors.py`
- `src/paqto/core/__init__.py`
- `src/paqto/__init__.py`

Tests:

- `tests/core/test_protocol.py`
- `tests/integration/test_request_reply.py` (new)

Documentation:

- `README.md`
- `docs/development_logs/2026-08-18_04-request-reply-ack.md` (this ignored log)

No application-domain concept, secret, certificate material, commit, or push
was added by this phase.

## Tests added

Coverage includes:

- normal request/reply and exact `reply_to` construction;
- forty concurrent correlations with deliberately reordered completion;
- request timeout and later reply consumption;
- unknown/wrong `reply_to` without dispatch or accidental completion;
- disconnect while a request is pending;
- node shutdown with a pending request;
- negotiated technical ACK and proof that it is not application-dispatched;
- technical ACK timeout cleanup;
- ACK requested on a session that did not negotiate support;
- ACK control-frame encode/decode separation;
- zero pending request/ACK Futures and zero supervised handler tasks after
  cleanup in every new integration test.

## Validation commands and results

Baseline:

- `python -m pytest -q`
  - Passed: `67 passed in 0.57s`.

Implementation checks completed before final validation:

- `python -m pytest -q tests/core/test_protocol.py tests/integration/test_request_reply.py`
  - Passed: `21 passed in 0.39s`.
- `python -m pytest -q`
  - Passed: `77 passed in 0.77s`.
- `python -m mypy src`
  - Passed after correcting local variable narrowing: no issues in 26 files.

Final validation:

- `python -X dev -m pytest -q -W error`
  - Passed: `77 passed in 0.91s`.
  - No pending-task, unclosed-stream, unclosed-socket, ResourceWarning, or
    unretrieved-Future warning was emitted.
- `python -m mypy src`
  - Passed: no issues in 26 source files.
- `python -m ruff check src tests examples --ignore PYI034`
  - Passed: all checks passed. `PYI034` remains intentionally ignored for the
    Python 3.10 `typing.Self` compatibility decision recorded previously.
- `python -m compileall -q src tests examples`
  - Passed.
- public import check for ACK capability and new exception classes
  - Passed: `import-ok paqto.ack.v1 RequestTimeoutError AcknowledgementTimeoutError`.
- `python -m pip check`
  - Passed: no broken requirements.
- `python examples/lan_two_nodes.py`
  - Passed: the fundamental plain-LAN message exchange still runs through the
    handshake/session layer.
- `git diff --check`
  - Passed with only the existing Windows LF-to-CRLF notices.
- generic-domain vocabulary scan across source, tests, examples, and README
  - No prohibited application-domain concepts found.
- final `git status --short` and `git check-ignore -v` review
  - Prior uncommitted phase files and the user's `.gitignore` modification are
    still present; this log is ignored by the unchanged development-log rule.

## Failure cases

- Reply deadline: `RequestTimeoutError`.
- Connection closes or node stops before reply: `RequestError`.
- ACK deadline: `AcknowledgementTimeoutError`.
- ACK support absent: `AcknowledgementUnavailableError` before message send.
- Connection closes or node stops before ACK: `AcknowledgementError`.
- Malformed ids/reply fields or unexpected control frames: protocol failure and
  connection cleanup.
- Unknown/late correlation ids: consumed without completing a Future or entering
  application handlers.

## Compatibility and risks

- Existing `send()` calls remain source-compatible; ACK waiting is opt-in.
- Existing `Message.id` and `reply_to` wire fields retain their intended generic
  correlation meaning.
- ACK-capable nodes advertise one additional handshake capability by default;
  older/current peers that do not advertise it simply negotiate no ACK support.
- Ordinary handler invocations are now concurrent across messages. Code that
  relied on undocumented global serial dispatch must add its own application
  synchronization. This change prevents protocol deadlocks and is documented in
  the README.
- `reply()` outside the receiving handler rejects ambiguous multiple READY
  sessions for the same peer rather than guessing.
- Reader/handler failures still lack the public supervision callback already
  identified in earlier phases; task exceptions are consumed but not surfaced
  through an event API.

## Future work

- Define public background error/supervision reporting.
- Define duplicate-session ownership and replacement before reconnect.
- Add reconnect/retry policy only after defining idempotency and retry-safe
  request semantics; never infer application success from ACK.
- If technical deduplication is later desired, specify exact scope (connection,
  session, or node), bounded capacity, TTL, eviction behavior, replay behavior,
  and the absence of application exactly-once guarantees before implementing it.
- Consider explicit cancellation control messages only as a separately
  negotiated protocol feature; local request cancellation currently performs
  local cleanup only.
- Consider deadline propagation only as generic protocol metadata with clear
  clock and trust semantics.
