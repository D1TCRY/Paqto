# Verifiable platform conformance and interoperability

Date: 2026-08-18  
Scope: offline conformance infrastructure, desktop CI, support evidence,
real-runtime procedure, and parameterized two-device interoperability

## Objective and constraints

Turn Paqto's capability-oriented portability contract into repeatable evidence.
A platform may be called tested only after the same conformance suite executes
on a real Python interpreter on that platform. The work adds development and
validation infrastructure, not runtime/application features or platform-named
core abstractions.

No commit or push was performed. Existing uncommitted portability, TLS, and
lifecycle work was preserved. Earlier development logs were not modified.

## Baseline and repository reconstruction

The three preceding cross-platform logs were read in full and compared with
the current implementation:

- `2026-08-18_10-portability-audit.md`;
- `2026-08-18_11-tls-context-portability.md`;
- `2026-08-18_12-lifecycle-network-portability.md`.

`pyproject.toml`, root tooling, package/build configuration, tests,
documentation, examples, Git status, and the accumulated diff were inspected.
No CI configuration existed at baseline. The project declared Python 3.10+
and had only pytest/pytest-asyncio in the development extra, while Ruff, mypy,
compileall, and build were invoked manually by earlier phases.

Available runtime: Windows 11, CPython 3.14.6, AMD64. The worktree already
contained all uncommitted changes from phases 10-12.

Baseline validation before this phase:

- ordinary suite: `175 passed in 3.02s`;
- development-mode suite with warnings as errors: `175 passed in 3.01s`;
- Ruff: passed;
- mypy: passed for 27 runtime source files;
- compileall: passed;
- `pip check`: passed.

## Conformance infrastructure

The new top-level `platform_conformance/` package is intentionally outside
`src`. It is runnable from a source checkout with a normal interpreter:

```console
python -m platform_conformance --profile full --json paqto-conformance.json
```

Setuptools still finds packages only under `src`, so conformance code and its
public deterministic TLS fixtures do not enter the runtime wheel. The isolated
build output was inspected and contained only `paqto` runtime packages.

The suite uses public Paqto APIs wherever possible. Its custom serializer and
no-discovery adapter implement public abstract contracts. Direct
standard-library socket binds are used only for environmental IPv4/IPv6/UDP
capability probes.

### Checks

Core:

- package import and Python 3.10+ contract;
- complete message serializer round-trip;
- exact and wildcard routing with sync/async handlers.

TCP/LAN:

- explicit IPv4 bind and explicit advertised host;
- loopback listener/connect;
- length-prefixed framing and multiple ordered frames;
- bidirectional data, disconnect, and a new connection after disconnect;
- a manually supplied `DiscoveredPeer`, without discovery.

Discovery:

- IPv4 UDP bind capability;
- a real broadcast request/announcement exchange between two local
  `LanDiscovery` instances;
- explicit UNAVAILABLE diagnostics when sockets open but the environment does
  not deliver broadcast.

TLS:

- local TLS with hostname verification;
- custom CA data loaded in memory rather than from the machine trust store;
- caller-prepared client/server `SSLContext` injection;
- mTLS, certificate identity resolution, strict Paqto peer-id binding, READY
  handshake, and secure request/reply.

Messaging/lifecycle/limits:

- send, technical ACK, request/reply, concurrent correlation, timeout, and
  caller cancellation;
- repeated start/stop, host-notified network refresh, idempotent stop, and
  cleanup counters;
- transport frame limit and negotiated message limit;
- pending-request admission limit and cancellation cleanup;
- bounded inbound queue rejection and public resource-limit event.

All network and trust activity is loopback/local. The suite has no Internet
dependency and does not use the host certificate store.

## Profiles, result model, and certification

Every check reports exactly one of:

- PASS: executed and satisfied its assertions;
- FAIL: execution demonstrated incorrect behavior;
- SKIP: deliberately not selected by the profile;
- UNAVAILABLE: an environmental capability could not be exercised.

Exit code `0` means all required checks passed, `1` means a check failed, and
`2` means no failure occurred but a profile-required capability was skipped or
unavailable. Required SKIP/UNAVAILABLE makes the report `INCOMPLETE`.

The `full` profile requires IPv4 broadcast discovery. The `ci` profile runs the
deterministic subset and marks broadcast SKIP because a hosted runner is not a
meaningful proof of LAN broadcast. IPv6 is always probed and recorded but is
currently optional to the IPv4 LAN profile.

The JSON schema records:

- platform system/release/machine and `sys.platform`, but no hostname or user;
- Python version/implementation and Paqto distribution version;
- IPv4, IPv6, TCP, UDP, broadcast discovery, TLS, and mTLS aggregates;
- passed, failed, skipped, unavailable, and total counts;
- per-check duration, requirement flag, status, and diagnostic.

The certification rule is deliberately strict: `SUPPORTED & TESTED` requires
an exit-0 `full` report from the real platform/runtime, retained with revision
or release evidence. A configured workflow or an unrelated operating system
cannot create that status.

## Desktop CI

`.github/workflows/ci.yml` adds a 3x3 hosted matrix:

- operating systems: Linux, macOS, Windows;
- Python: 3.10 (minimum), 3.12 (intermediate), 3.14 (current declared/tested
  series).

Every job installs `.[dev]`, then runs pytest in development mode with warnings
as errors, Ruff, mypy, compileall, an isolated sdist/wheel build, and the `ci`
conformance profile. Each machine-readable conformance report is uploaded as a
job artifact. The workflow sets no asyncio event-loop policy.

`pyproject.toml` now declares the Ruff, mypy, and build tools in the development
extra and adds the Python 3.14 classifier. There is no runtime dependency or
runtime package addition.

The workflow was syntax-parsed locally as a 3-operating-system by
3-Python-version matrix. It was not executed from this workspace, so its nine
entries remain expected rather than tested evidence.

## Real Android procedure and state

`docs/platform-testing.md` defines a generic procedure:

1. run a supported Python interpreter on a real device or emulator;
2. install the local Paqto source/wheel and transfer the conformance directory;
3. have the host grant required network permissions;
4. execute the unchanged full profile inside that runtime;
5. retain exit code and JSON with revision/runtime evidence;
6. update the support matrix only for capabilities that actually passed.

No device/emulator with an executable Python runtime was available in the
current environment. Android status is therefore exactly: **awaiting real
Android execution**. Desktop Linux is not labeled Android and no Android pass
is claimed.

## Two-device interoperability tool

`tools/two_device_interop.py` provides server/client roles with all bind,
advertised, remote, discovery, timeout, certificate, key, CA, identity-prefix,
and security-mode values supplied as arguments. It supports explicit endpoints
or UDP discovery and plain, TLS, or mTLS sessions without changing library
code.

The client verifies:

- READY protocol handshake;
- TCP and configured TLS/mTLS state;
- technical ACK and request/reply;
- explicit disconnect;
- a fresh transport/TLS/Paqto session;
- a second request/reply.

The server independently observes two distinct public connection objects,
READY sessions, request/reply, security state, and cleanup. Both roles emit
small JSON evidence and the server can terminate automatically after the two
requests, making external automation straightforward.

Actual local execution on this host:

- two independent processes with explicit loopback endpoints and mTLS: PASS;
- both peers verified TLS, mTLS, READY handshake, two request/reply rounds,
  fresh reconnect, and cleanup;
- a separate cross-process broadcast-discovery attempt did not find the peer
  before its deadline on this host. The tool reported FAIL rather than silently
  switching modes. The deterministic full conformance broadcast exchange
  between two local discovery instances did pass. Real two-device broadcast
  remains a hardware/network validation item.

No Windows-to-Windows physical-device, Android-to-Windows, or
Android-to-Android result is claimed from the local two-process exercise.

## Documentation and official support matrix

Added `docs/platform-testing.md` and linked it from README and the documentation
index. `docs/platform-support.md` now defines the official status vocabulary
and records only the available Windows 11 / CPython 3.14.6 full run as
`SUPPORTED & TESTED`. Configured but unexecuted desktop matrix entries are
`EXPECTED`; Android is `UNVERIFIED`.

The matrix separates TCP, UDP discovery, and TLS evidence. A full Windows result
on one exact runtime is not generalized to every Python version, network
driver, firewall policy, or Windows release.

## Actual execution in this phase

Conformance on Windows 11 / CPython 3.14.6:

- full profile: `14 PASS`, `0 FAIL`, `0 SKIP`, `0 UNAVAILABLE`, exit `0`;
- ci profile: `13 PASS`, `0 FAIL`, `1 SKIP` (broadcast), `0 UNAVAILABLE`, exit
  `0`;
- reported IPv4, IPv6 loopback, TCP, UDP, local broadcast, TLS, and mTLS:
  PASS.

Interoperability:

- explicit two-process loopback mTLS run: both server and client exit `0` with
  TCP/TLS/mTLS/READY/request/reply/reconnect/cleanup PASS;
- discovery-enabled two-process attempt: not passed and not used as support
  evidence.

Build:

- the first isolated build attempt failed only because the sandbox denied
  creation of the temporary venv;
- the approved isolated build then produced `paqto-0.0.1.tar.gz` and
  `paqto-0.0.1-py3-none-any.whl` successfully;
- generated tracked egg-info was restored to its exact pre-build content;
- the wheel contains no conformance or two-device tooling.

Final repository checks are recorded below after the log itself was added.

Final validation:

- `python -m pytest -q`: `178 passed`;
- `python -X dev -m pytest -q -W error`: `178 passed`, with no pending-task,
  ResourceWarning, unclosed-stream/socket, or unretrieved-Future warning;
- `python -m ruff check src tests examples platform_conformance tools`: passed;
- `python -m mypy src platform_conformance tools`: passed for 33 files;
- `python -m compileall -q src tests examples platform_conformance tools`:
  passed;
- Python 3.10 grammar parse: passed for 53 Python files;
- `python -m pip check`: passed;
- `python -m platform_conformance --profile full`: 14 PASS, exit `0`;
- `python -m platform_conformance --profile ci`: 13 PASS / 1 deliberate
  broadcast SKIP, exit `0`;
- isolated `python -m build`: sdist and wheel passed after temporary-directory
  permission was granted;
- CI YAML parse: 3 operating systems by 3 Python versions;
- documentation link check: 16 Markdown files passed;
- prohibited-vocabulary, Internet-address-heuristic, signal, and event-loop
  policy scans: passed;
- `git diff --check`: passed with line-ending conversion warnings only.

## Risks and limitations

- A same-host broadcast pass is useful but does not prove firewall, multicast
  lock, AP isolation, or packet delivery between physical devices.
- Hosted CI executes real operating systems but its `ci` profile deliberately
  cannot certify broadcast discovery.
- Ephemeral local ports still have a small allocate/close/rebind race inherent
  in black-box public-node testing.
- Public conformance private keys are test fixtures with no secrecy and must
  never be deployed.
- The suite verifies one IPv4 LAN profile. IPv6 loopback capability is reported,
  but end-to-end IPv6, IPv6-only, dual-stack, link-local scope, and
  multi-interface routing remain separate real-network work.
- Default platform trust stores are deliberately not used, so this suite proves
  custom trust and SSLContext paths rather than the composition of each system
  trust store.
- A report proves the exact code/runtime/capability execution it records, not
  future releases or untested host policies.

## Recommended roadmap

1. Run the hosted matrix and retain all nine JSON artifacts; update the support
   matrix only from completed jobs.
2. Run the full suite on a real supported Android Python runtime and preserve
   the report without weakening or renaming required checks.
3. Run the interoperability tool across two physical Windows hosts, then
   Android/Windows and Android/Android pairs, with explicit and discovery modes.
4. Add opt-in real-network profiles for offline LAN, IPv6-only/dual-stack,
   multi-interface advertisement, network handover, and suspend/resume.
5. Version the JSON schema compatibly if new required capabilities are added.
6. Keep runtime APIs capability-oriented; platform certification belongs to
   evidence and documentation, not platform-named core classes.
