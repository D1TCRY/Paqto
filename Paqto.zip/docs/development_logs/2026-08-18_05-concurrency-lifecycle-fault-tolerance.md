# Concurrency, Lifecycle, and Fault Tolerance

## Phase objective

Make Paqto robust across temporary reachability loss, connection closure,
reappearance, concurrent connection attempts, and simultaneous cross-connects.
The phase adds a generic logical connection state machine, deterministic
duplicate-session ownership, optional reconnect with exponential backoff,
protocol heartbeat control frames, and discovery TTL handling.

The implementation remains transport-agnostic and domain-agnostic. It adds no
application roles, durable queues, message retry, session resumption, custom
cryptography, or application-specific behavior.

## Initial state

- The current uncommitted worktree from the foundation, TLS, protocol-handshake,
  and request/reply phases was treated as the source of truth.
- Every development log was reread, with particular attention to
  `2026-08-18_03-protocol-handshake.md` and
  `2026-08-18_04-request-reply-ack.md`.
- `ConnectionManager`, `PaqtoNode`, the abstract `Connection`, discovery models
  and service, LAN TCP connection/listener/transport, TLS adapter, protocol
  control frames, request/reply cleanup, tests, README, example, and public
  exports were traced before editing.
- Git status contained all prior phase changes plus the pre-existing user
  modification to `.gitignore`. No unrelated change was overwritten.
- `docs/development_logs/` remains ignored by the existing
  `.gitignore:2:docs/development_logs/` rule. Previous logs and Git policy were
  not modified.
- Baseline command: `python -m pytest -q`.
- Baseline result: `77 passed in 0.76s`.

## State machine

`ConnectionState` is public and describes the logical connection to one peer,
not the lifetime of one physical socket:

```text
DISCONNECTED
    -> CONNECTING -> CONNECTED
    -> RECONNECTING -> CONNECTED
    -> RECONNECTING -> DISCONNECTED  (policy exhausted or peer expired)

CONNECTED -> DISCONNECTED            (unexpected loss)
CONNECTED -> CLOSING -> CLOSED        (explicit disconnect or shutdown)
```

`ConnectionManager.state()` and `PaqtoNode.connection_state()` expose the
state. `PaqtoNode.connection_for_peer()` exposes the single canonical READY
connection. A reconnect creates a new physical `Connection`, repeats all
handshakes, and installs a new `ProtocolSession`; it does not mutate an old
connection into a new security context.

The states retained are all operationally meaningful. `CLOSING` is observable
while resources are being released; `CLOSED` distinguishes deliberate terminal
closure from an unexpected `DISCONNECTED` state that may be reconnectable.

## ConnectionManager concurrency

The previous manager held one lock across transport connect and protocol
preparation. This prevented same-peer duplication but unnecessarily serialized
unrelated peers and did not coordinate incoming READY sessions.

The manager now uses per-peer single-flight tasks:

- the first caller creates the transport/preparation task;
- concurrent callers for the same peer await that task through
  `asyncio.shield`, so cancelling one waiter does not cancel the shared attempt;
- different peers may connect concurrently;
- only short cache/state mutations use the manager lock;
- close of a peer or all peers cancels owned in-flight tasks and closes cached
  connections;
- a preparation callback may return an already established canonical
  connection when an inbound session wins duplicate resolution;
- `adopt()` lets a validated inbound session become the manager's canonical
  connection.

Failed and cancelled preparation still closes the newly opened connection and
never caches a non-READY channel.

## Deterministic duplicate-session policy

Paqto now keeps at most one READY application session for a logical peer.
Direction is internal protocol/session metadata (`inbound` or `outbound`) and
does not describe an application role.

For simultaneous A-to-B and B-to-A opens, both ends independently apply the
same stable rule:

> The peer with the lexicographically smaller `Peer.id` keeps its outbound
> channel. The other peer keeps the corresponding inbound channel.

The two nodes therefore retain opposite ends of the same physical connection.
When duplicates have the same direction, the first session to reach READY is
kept. A losing session is removed from READY registries before close, its
pending request/ACK state fails, and its eventual reader cleanup cannot remove
or reconnect over the winning session.

This policy is generic, symmetric, independent of addresses and timing after
READY, and does not trust discovery. Security and Paqto identity validation
occur before a connection participates in duplicate selection.

## Reconnect algorithm

Reconnect is configured through the immutable public `ReconnectPolicy`:

- `enabled` (default false);
- `initial_delay`;
- `multiplier` (at least one);
- `maximum_delay`;
- `jitter` as a zero-to-one fractional range (default zero);
- `max_attempts`, either a positive integer or `None` for indefinite mode.

The delay before zero-based attempt `n` is:

```text
min(maximum_delay, initial_delay * multiplier ** n)
```

Optional jitter multiplies that bounded delay by a factor in
`[1 - jitter, 1 + jitter]`. Delays must be positive, so reconnect cannot create
a busy loop. The default zero jitter keeps behavior deterministic unless a
deployment explicitly requests spreading.

Only an unexpected loss of the canonical session schedules reconnect. An
explicit `node.disconnect(peer)` suppresses it until a later explicit
`connect()`. The reconnect loop rereads the newest fresh `DiscoveredPeer`
before each attempt. `node.stop()` cancels both a current attempt and a task
sleeping in backoff, then gathers it before returning.

Each successful attempt runs a new transport connection (and therefore a new
TLS handshake when configured), a new Paqto hello exchange, serializer/version
negotiation, discovery-claim check, and authenticated identity binding. No
security state from the previous socket is reused.

`last_reconnect_error(peer)` provides the most recent failed attempt for
diagnostics. A terminal background failure is retained rather than raised into
an unrelated application coroutine.

## Heartbeat semantics

The protocol adds capability `paqto.heartbeat.v1` and two READY-state control
frames:

- PING with a unique `ping_id`;
- PONG with exactly the corresponding `ping_id`.

They use the existing bounded JSON control-frame channel and never enter the
application serializer, `MessageRouter`, handlers, request correlation, or ACK
correlation. A heartbeat control frame received without negotiated support is
a protocol error.

`PaqtoConfig.heartbeat_interval` is `None` by default, so no heartbeat task is
started unless explicitly enabled. Current nodes advertise the capability even
when they do not initiate heartbeats, allowing them to answer a negotiated
PING. `heartbeat_timeout` is required when an interval is enabled.

Any valid inbound frame updates connection activity. If inbound traffic was
seen during the interval, no PING is sent. Otherwise the node registers the
pending PONG before sending PING, preventing a response-before-registration
race. A matching PONG completes only the waiter for the exact connection. A
timeout closes that connection; normal reader cleanup then fails its pending
operations and may schedule reconnect.

Heartbeat tasks, waiters, last-activity entries, and completion callbacks are
owned by `PaqtoNode` and are cancelled/cleared on replacement, connection loss,
explicit disconnect, and node shutdown.

## Peer TTL

`DiscoveredPeer` adds `freshness()` and `is_fresh()` with public
`PeerFreshness.FRESH` / `EXPIRED` results. TTL is evaluated against the
timezone-aware `last_seen`. `None` explicitly disables expiry.

`PaqtoConfig.peer_ttl` defaults to 60 seconds. Expired discovery information:

- is filtered from `PaqtoNode.discover()` results;
- cannot initiate a new connection;
- cannot drive reconnect.

`LanDiscovery.peer_ttl` also defaults to 60 seconds and removes expired entries
from its own cache before returning discovery results. A newly received announce
updates the existing peer and refreshes `last_seen`.

A currently live READY connection remains usable after discovery TTL expires:
the established session is stronger evidence of present reachability than a
missing UDP announce. TTL remains only a reachability policy, never identity,
authentication, authorization, or trust.

## Request/reply interaction

Pending requests and ACKs remain scoped to the exact connection object and
session peer. Canonical connection cleanup fails those futures before reconnect
is scheduled. The new connection has a different object and `ProtocolSession`,
so a reply or ACK arriving after reconnect cannot complete an operation from the
old session.

Paqto still does not automatically retry or resend application messages,
requests, replies, or ACK waits. Reconnect restores connectivity only.

## Race conditions found and resolved

1. Incoming and outgoing READY sessions used separate ownership sets, so a
   simultaneous cross-connect could leave two valid sessions and make routing
   ambiguous. Canonical per-peer selection now resolves this before dispatch.
2. A global manager lock prevented useful parallel connects. Per-peer
   single-flight retains same-peer safety without global serialization.
3. Cancelling one caller could otherwise cancel shared work. Shielded waiters
   separate caller cancellation from manager-owned attempt cancellation.
4. A losing reader could remove the winner's state during delayed cleanup.
   Every removal now compares exact connection identity.
5. Pending request/ACK state could be confused by replacement if keyed only by
   peer. It remains bound to the exact old connection and is failed before
   reconnect.
6. PONG could arrive before a heartbeat waiter existed. Registration now occurs
   before send.
7. Reconnect and heartbeat tasks could survive shutdown without explicit
   ownership. Both have registries, done callbacks, cancellation, and gather
   paths.
8. LAN transport/listener sets retained closed connections until final stop.
   Successful subsequent connections now prune closed references, preventing
   accumulation over repeated reconnect cycles.
9. Repeated tests exposed a short interval where `DISCONNECTED` was observable
   while heartbeat `wait_closed()` was still finishing. Heartbeat registry
   removal is now performed in the task's own `finally`, and tests wait for the
   completed cleanup boundary.

## Files modified in this phase

Runtime and public API:

- `src/paqto/core/config.py`;
- `src/paqto/core/connection.py`;
- `src/paqto/core/discovered.py`;
- `src/paqto/core/errors.py`;
- `src/paqto/core/manager.py`;
- `src/paqto/core/node.py`;
- `src/paqto/core/protocol.py`;
- `src/paqto/core/__init__.py`;
- `src/paqto/__init__.py`;
- `src/paqto/connection.py`;
- `src/paqto/lan/discovery.py`;
- `src/paqto/lan/listener.py`;
- `src/paqto/lan/transport.py`.

Tests:

- `tests/core/test_connection_manager.py`;
- `tests/core/test_protocol.py`;
- `tests/core/test_reliability_models.py` (new);
- `tests/lan/test_lan_discovery.py`;
- `tests/integration/test_fault_tolerance.py` (new).

Documentation:

- `README.md`;
- `docs/development_logs/2026-08-18_05-concurrency-lifecycle-fault-tolerance.md`
  (this ignored file).

No `.gitignore` change, secret material, application-domain concept, commit, or
push was added by this phase.

## Tests added or extended

Coverage includes:

- same-peer concurrent connect single-flight and explicit state transitions;
- different-peer connection attempts proceeding concurrently;
- cancellation of one shared-connect waiter;
- simultaneous A-to-B and B-to-A opens selecting the documented one session;
- explicit disconnect and manual reconnect;
- successful reconnect with a new connection and new `ProtocolSession`;
- exhausted reconnect attempts;
- exact bounded exponential backoff;
- stop while sleeping in indefinite reconnect backoff;
- heartbeat PING/PONG success;
- heartbeat timeout and connection closure;
- proof that heartbeat frames are not application data;
- discovery freshness boundaries and LAN cache pruning;
- expired discovery rejection before a new connection;
- pending request failure on old-session disconnect;
- successful request/reply on the new session without reviving old correlation;
- mutual TLS authentication and Paqto identity binding repeated after reconnect;
- zero node-owned reader, handler, heartbeat, reconnect, heartbeat-waiter,
  request, and ACK state after shutdown.

## Validation commands and results

Baseline:

- `python -m pytest -q`
  - Passed: `77 passed in 0.76s`.

Intermediate checks:

- targeted reliability/protocol/manager/discovery tests
  - Passed: `38 passed in 1.01s`.
- first full suite after implementation
  - Passed: `96 passed in 1.65s`.
- after adding manager cancellation/parallelism coverage
  - Passed in development mode: `98 passed in 1.72s`.
- `python -m mypy src`
  - Passed during implementation; one later local-variable shadowing issue was
    found after heartbeat cleanup tightening and corrected before final checks.
- `python -m ruff check src tests examples --ignore PYI034`
  - Passed after deterministic import/export ordering and the intentional
    reconnect adapter-supervision catch were documented.

Flake checks:

- five initial repeated development-mode runs of
  `tests/integration/test_fault_tolerance.py` exposed the heartbeat cleanup
  observation described above (three passes followed by two failures).
- after the lifecycle correction, ten consecutive development-mode runs passed:
  `9 passed` on every run.
- two consecutive full development-mode suites then passed:
  `98 passed in 1.66s` and `98 passed in 1.64s`.

Final validation:

- `python -X dev -m pytest -q -W error`
  - Passed: `98 passed in 1.69s`.
  - No pending-task, unclosed-stream, unclosed-socket, `ResourceWarning`, or
    unretrieved-Future warning was emitted.
- `python -m mypy src`
  - Passed: no issues in 26 source files.
- `python -m ruff check src tests examples --ignore PYI034`
  - Passed: all checks passed. `PYI034` remains the previously documented
    Python 3.10 `typing.Self` compatibility exception.
- `python -m compileall -q src tests examples`
  - Passed.
- public import check for `ConnectionState`, `ReconnectPolicy`,
  `PeerFreshness`, heartbeat capability, and default TTL
  - Passed: printed `import-ok connected paqto.heartbeat.v1 expired 3 60.0`.
- `python -m pip check`
  - Passed: no broken requirements.
- `python examples/lan_two_nodes.py`
  - Passed: the fundamental plain-LAN example completed handshake and message
    exchange.
- `git diff --check`
  - Passed with only existing Windows LF-to-CRLF conversion notices.
- `git check-ignore -v` for this log
  - Confirmed `.gitignore:2:docs/development_logs/`.
- application-domain vocabulary scan over source, tests, example, README, and
  this log
  - No prohibited application-domain concepts found.

## Compatibility and risks

- Reconnect remains disabled by default, and heartbeat initiation remains
  disabled by default.
- Current nodes advertise heartbeat response support as a capability. Older
  peers that do not advertise it negotiate no heartbeat and receive no PING.
- `ConnectionManager.connect()` remains compatible with preparation callbacks
  returning `None`; callbacks may now also return a canonical replacement.
- The default 60-second discovery TTL intentionally changes indefinite cache
  behavior: stale peers no longer remain automatically reachable forever.
  `None` is an explicit compatibility opt-out.
- Duplicate READY sessions are no longer exposed. Code relying on ambiguous
  parallel sessions for one peer must build that behavior above the single
  canonical Paqto session or use the transport directly.
- Ordering uses exact `Peer.id` string comparison. Peer ids therefore need to be
  stable within the protocol identity model already required by handshake.
- Wall-clock changes can affect TTL. Future timestamps are treated as fresh to
  avoid false expiry after a backward clock adjustment.
- Jitter uses process randomness for scheduling only, not security.

## Edge cases intentionally left open

- There is still no general public node event stream for reader, handler,
  accept-loop, or terminal reconnect errors. Only the latest reconnect error is
  exposed for diagnostics.
- There is no durable queue, message retry, retransmission, deduplication,
  exactly-once guarantee, application idempotency, or session resumption.
- Reconnect requires a fresh known discovery endpoint. A peer known only from an
  inbound connection cannot be dialed back unless discovery later supplies a
  reachable endpoint.
- A changed endpoint learned during one in-progress attempt is used on the next
  attempt; an already-open transport call is not redirected mid-call.
- Discovery UDP remains spoofable and cannot authenticate the endpoint or peer.
  Every new connection still relies on security/handshake identity validation.
- Incoming handshake concurrency still has no configurable global admission
  limit; network/transport resource controls remain important.
- Heartbeat detects missing protocol responses, not application health or
  durable processing.
- No cross-platform or multi-version CI was available; validation was performed
  on Windows with Python 3.14.6.

## Guidance for the next phase

1. Add a generic public supervision/error event before layering more background
   services on the node.
2. Keep reconnect separate from message retry; define retry safety,
   idempotency, deadlines, and deduplication before resending any application
   envelope.
3. If discovery sources need different TTLs, expose source-specific freshness
   policy without turning discovery into authorization.
4. Consider configurable incoming-handshake and handler concurrency limits for
   resource-exhaustion control.
5. Preserve exact-connection scoping for all future correlation or delivery
   control frames.
