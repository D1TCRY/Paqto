# LAN TCP Transport Implementation Report

## 1. Recommended Git Commit Title

`feat: add TCP LAN transport`

## 2. Task Summary

Implemented the first concrete LAN communication transport for Paqto using TCP and asyncio streams. The work adds a new `paqto.lan` package with a transport, listener, connection, and address helpers.

This was implemented so Paqto can open real byte-frame connections over a local network while preserving the existing transport-agnostic core abstractions. It fits the current architecture by implementing `paqto.core.transport.Transport`, `paqto.core.listener.Listener`, and `paqto.core.connection.Connection` without changing their public APIs. `PaqtoNode.start()` can create and start the LAN listener, advertise `listener.local_endpoint`, and later read complete byte frames through `Connection.receive_frame()`.

## 3. Files Changed

- `src/paqto/lan/__init__.py`
  - Status: created
  - Purpose: Public package entry point for the LAN transport implementation.
  - Changes made: Exports `LanTransport`, `TcpListener`, and `TcpConnection` through `__all__`.

- `src/paqto/lan/address.py`
  - Status: created
  - Purpose: Shared helpers for LAN endpoint address parsing, endpoint construction, socket address handling, advertised host selection, and frame size validation.
  - Changes made: Added `TRANSPORT_NAME = "lan"`, `TCP_SCHEME = "tcp"`, `MAX_UINT32`, the `TcpAddress` dataclass, `parse_tcp_address()`, `build_tcp_address()`, `endpoint_from_host_port()`, `endpoint_from_sockname()`, `parse_sockname()`, `choose_advertised_host()`, and `validate_max_frame_size()`.

- `src/paqto/lan/connection.py`
  - Status: created
  - Purpose: TCP-backed implementation of the core `Connection` abstraction.
  - Changes made: Added `TcpConnection`, based on `asyncio.StreamReader` and `asyncio.StreamWriter`, with complete frame send/receive support using a 4-byte unsigned big-endian length prefix.

- `src/paqto/lan/listener.py`
  - Status: created
  - Purpose: TCP-backed implementation of the core `Listener` abstraction.
  - Changes made: Added `TcpListener`, based on `asyncio.start_server()`, with accepted connections queued and returned as `TcpConnection` instances.

- `src/paqto/lan/transport.py`
  - Status: created
  - Purpose: TCP LAN implementation of the core `Transport` abstraction.
  - Changes made: Added `LanTransport`, with transport name `"lan"`, lifecycle handling, listener creation, outgoing TCP connection creation, endpoint validation, and network error translation to `TransportError`.

- `docs/development_logs/2026-05-17-lan-tcp-transport.md`
  - Status: created
  - Purpose: Markdown development log documenting the completed LAN TCP transport implementation.
  - Changes made: Added this implementation report. This file is documentation only and is not used by the runtime package.

## 4. Detailed Implementation Notes

### New `paqto.lan` package

The implementation adds a new `paqto.lan` package under `src/paqto/lan`. It is independent from the existing core package and does not modify `paqto.core`.

The package exports:

- `LanTransport`
- `TcpListener`
- `TcpConnection`

### Address format and endpoint rules

LAN endpoints use the existing core `Endpoint` dataclass:

```python
Endpoint(
    transport="lan",
    address="tcp://HOST:PORT",
    metadata={...},
)
```

The address helpers enforce the `tcp://HOST:PORT` format. Invalid schemes, missing hosts, missing ports, invalid ports, user info, paths, query strings, fragments, or params are rejected with `TransportError`.

IPv6 address formatting is partially supported when building addresses by wrapping hosts containing `:` in brackets.

### `LanTransport`

`LanTransport` implements `paqto.core.transport.Transport`.

Constructor:

```python
LanTransport(
    host: str = "0.0.0.0",
    port: int = 0,
    max_frame_size: int = 16 * 1024 * 1024,
)
```

Important behavior:

- `name` returns exactly `"lan"`.
- `start()` marks the transport as started.
- `stop()` closes all listeners and outgoing connections created by the transport.
- `create_listener(bind=None)` creates a `TcpListener` using either the transport default host/port or a supplied LAN `Endpoint`.
- `connect(endpoint, timeout=None)` validates `endpoint.transport == "lan"`, parses `endpoint.address`, opens an asyncio TCP connection, and returns a `TcpConnection`.
- `OSError` during TCP connection attempts is translated into `TransportError`.
- `TimeoutError` from the optional timeout is allowed to propagate so the existing `ConnectionManager` timeout handling can translate it to `PaqtoTimeoutError`.

### `TcpListener`

`TcpListener` implements `paqto.core.listener.Listener`.

Important behavior:

- Uses `asyncio.start_server()` to accept incoming TCP connections.
- Keeps accepted connections in an internal `asyncio.Queue`.
- `accept()` returns `TcpConnection` instances.
- `local_endpoint` is available before and after start, but after `start()` it uses the actual assigned port from the server socket.
- If the configured port is `0`, the endpoint address is updated to the real OS-assigned port.
- `local_endpoint.transport` is always `"lan"`.
- `local_endpoint.address` is always built as `tcp://HOST:PORT`.
- `close()` is idempotent and closes the asyncio server.
- Calling `accept()` after close raises `ConnectionClosedError`.

When binding to `0.0.0.0`, `::`, or an empty host, the listener tries to publish a primary local IPv4 address. If that cannot be detected, it tries hostname IPv4 resolution and finally falls back to the configured bind host. The endpoint metadata records:

- `bind_host`: the host actually configured for binding.
- `advertised_host_source`: one of `bind_host`, `primary_ipv4`, or `hostname_ipv4`.

### `TcpConnection`

`TcpConnection` implements `paqto.core.connection.Connection`.

Important behavior:

- Uses `asyncio.StreamReader` and `asyncio.StreamWriter`.
- Exposes `local_endpoint`, `remote_endpoint`, and `is_closed`.
- Sends and receives complete byte frames only.
- Does not serialize or deserialize Paqto messages.
- Does not include any discovery behavior.

Framing format:

1. 4-byte unsigned big-endian payload length.
2. Raw payload bytes.

`send_frame(data)`:

- Raises `ConnectionClosedError` if the connection is closed.
- Raises `TransportError` if `len(data) > max_frame_size`.
- Writes the length header plus payload.
- Awaits `writer.drain()`.
- Converts network write failures into `ConnectionClosedError`.

`receive_frame()`:

- Raises `ConnectionClosedError` if the connection is closed.
- Reads exactly 4 bytes for the header.
- Parses the payload length.
- Raises `TransportError` and closes the connection if the incoming frame exceeds `max_frame_size`.
- Reads exactly the declared payload length.
- Returns only the payload bytes, never the header.
- Converts premature EOF or read failures into `ConnectionClosedError`.

`close()`:

- Closes the writer safely.
- Awaits `writer.wait_closed()`.
- Is idempotent.

### Interaction With Existing Paqto Components

No existing core APIs were changed.

The implementation follows the existing contracts:

- `Transport.name` matches `Endpoint.transport`.
- `LanTransport.name == "lan"`.
- `TcpConnection.receive_frame()` returns exactly one complete byte frame, which is what `PaqtoNode._read_connection()` passes to the configured serializer.
- `PaqtoNode.start()` can start the transport, create/start a listener, and pass `listener.local_endpoint` to discovery.
- `ConnectionManager` can use `LanTransport.connect()` to open outgoing connections for discovered LAN endpoints.

## 5. Tests and Validation

No persistent test files were added or updated.

Validation commands and checks run during the task:

- `python -m compileall src\paqto`
  - Result: passed.
  - Purpose: verified syntax/import compilation for the package after adding the LAN module.

- Inline asyncio round-trip script with `PYTHONPATH=src` and `python -B -`
  - Result: passed.
  - Purpose: verified that:
    - `LanTransport` starts.
    - `TcpListener` starts on `127.0.0.1` with `port=0`.
    - `listener.local_endpoint` uses transport `"lan"`.
    - the assigned endpoint address contains a real non-zero TCP port.
    - `LanTransport.connect()` opens a TCP connection.
    - accepted connections are returned by `TcpListener.accept()`.
    - `send_frame()` and `receive_frame()` perform a byte payload round trip.
    - oversized outgoing frames raise `TransportError`.
    - sending after close raises `ConnectionClosedError`.
    - accepting after listener close raises `ConnectionClosedError`.

- Inline `PaqtoNode` integration script with fake in-memory discovery and pickle-based serializer
  - Result: passed.
  - Purpose: verified that two `PaqtoNode` instances can use `LanTransport` end to end through the existing node lifecycle, discovery shape, serializer boundary, connection manager, and message receive loop.

- Inline syntax compilation for `src/paqto/lan/*.py` using `compile()`
  - Result: passed.
  - Purpose: rechecked syntax without leaving `__pycache__` files.

Not tested or not validated:

- Real communication between two different machines on the same LAN.
- Firewall/NAT behavior.
- IPv6 end-to-end behavior.
- High concurrency with many simultaneous connections.
- Long-running connection cleanup behavior under repeated reconnects.
- TLS or authentication.
- Real discovery service integration.
- Packaging/build verification after adding the new package.

## 6. Known Limitations and Follow-Up Work

- Discovery is intentionally not implemented in this task.
- TCP transport handles bytes only; message serialization remains the responsibility of Paqto serializers.
- No TLS, authentication, encryption, peer verification, or integrity checks are included.
- When binding to `0.0.0.0`, advertised host selection is a best-effort first version. It may choose the wrong interface on machines with multiple active networks.
- Closed outgoing connections remain tracked by `LanTransport` until `stop()`; this is acceptable for the first version but could be refined.
- There are no persistent automated tests yet. The inline validation scripts should be converted into proper unit/integration tests.
- Packaging should be checked with the project build workflow to confirm the new `paqto.lan` package is included as expected.
- Future work should include real LAN discovery, multi-machine validation, IPv6 coverage, connection cleanup/pruning, and configurable socket options if needed.
