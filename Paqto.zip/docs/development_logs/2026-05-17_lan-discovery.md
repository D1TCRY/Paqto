# LAN Discovery Implementation Report

## 1. Recommended Git commit title

`feat: add LAN UDP discovery`

## 2. Task summary

Implemented a concrete `LanDiscovery` service for Paqto using UDP broadcast over IPv4. The implementation provides JSON-based LAN peer discovery with `discover` and `announce` packets, matching the existing `DiscoveryService` contract exactly:

```python
DiscoveryService.start(local_peer: Peer, endpoints: Sequence[Endpoint])
DiscoveryService.stop()
DiscoveryService.discover(timeout: float | None = None) -> list[DiscoveredPeer]
```

This was implemented so Paqto nodes can find other peers on the local network without coupling discovery to the TCP transport or to application message serialization. Architecturally, `LanDiscovery` lives in `paqto.lan` beside the existing LAN TCP transport and plugs into the core through the existing `DiscoveryService` abstraction. No core discovery API changes were introduced.

## 3. Files changed

- `src/paqto/lan/discovery.py`
  - Status: created
  - Purpose: provides the concrete LAN discovery implementation for Paqto using UDP broadcast and JSON discovery packets.
  - Changes made: added `LanDiscovery(DiscoveryService)`, UDP datagram protocol handling, packet serialization/deserialization, periodic announces, active discovery requests, peer cache management, endpoint validation, startup/shutdown lifecycle handling, and helper validation/copy functions.

- `src/paqto/lan/__init__.py`
  - Status: modified
  - Purpose: exposes public LAN package APIs.
  - Changes made: imported `LanDiscovery` from `paqto.lan.discovery` and added it to `__all__`.

## 4. Detailed implementation notes

### New public class

`LanDiscovery` was added as a concrete implementation of `DiscoveryService`.

Constructor parameters:

- `discovery_port: int = 37020`
- `bind_host: str = "0.0.0.0"`
- `broadcast_host: str = "255.255.255.255"`
- `announce_interval: float = 5.0`
- `default_discover_timeout: float = 1.0`
- `metadata: Mapping[str, Any] | None = None`
- `max_datagram_size: int = 65_507`

Internal state:

- `_local_peer: Peer | None`
- `_endpoints: list[Endpoint]`
- `_discovered: dict[str, DiscoveredPeer]`
- `_transport: asyncio.DatagramTransport | None`
- `_announce_task: asyncio.Task[None] | None`

### Lifecycle behavior

`start(local_peer, endpoints)`:

- Copies and stores the local peer.
- Filters publishable endpoints to valid LAN endpoints only.
- Requires endpoint transport to be `"lan"`.
- Requires endpoint addresses to parse as `tcp://HOST:PORT` using the existing LAN address parser.
- Opens an IPv4 UDP socket.
- Enables `SO_REUSEADDR`.
- Attempts `SO_REUSEPORT` when available.
- Enables `SO_BROADCAST`.
- Binds to the configured bind host and discovery port.
- Creates an asyncio datagram endpoint.
- Starts a periodic announce task.
- Raises `DiscoveryError` for meaningful discovery startup failures.

`stop()`:

- Cancels the periodic announce task.
- Closes the UDP datagram transport.
- Clears local peer and endpoint state.
- Clears the discovered peer cache.
- Is idempotent.

`discover(timeout=None)`:

- Requires the service to be started.
- Raises `DiscoveryError` if called before `start()`.
- Sends a JSON `discover` packet by UDP broadcast.
- Waits for a bounded collection window.
- Returns the current peer cache as `list[DiscoveredPeer]`.
- Uses `default_discover_timeout` when `timeout` is `None`.
- May return peers discovered before the current call, with any fresh announces applied before returning.
- Uses a small internal guard window so it can complete before an outer `PaqtoNode.discover()` timeout wrapper expires.

### Discovery protocol

Protocol version constant:

- `PROTOCOL_VERSION = 1`

Supported packet kinds:

- `discover`
- `announce`

`discover` packets include:

```json
{
  "paqto": 1,
  "kind": "discover",
  "peer_id": "..."
}
```

`announce` packets include:

```json
{
  "paqto": 1,
  "kind": "announce",
  "peer": {
    "id": "...",
    "name": "...",
    "metadata": {}
  },
  "endpoints": [
    {
      "transport": "lan",
      "address": "tcp://HOST:PORT",
      "metadata": {}
    }
  ],
  "metadata": {}
}
```

Periodic announces are broadcast. Announces sent in response to `discover` packets are sent back to the sender UDP address.

### Packet receive behavior

The private `_LanDiscoveryProtocol` delegates incoming datagrams to `LanDiscovery._datagram_received()`.

Incoming packets are ignored when:

- the datagram exceeds the configured maximum size;
- UTF-8 decoding fails;
- JSON decoding fails;
- the decoded payload is not a JSON object;
- the `paqto` protocol version does not match;
- the packet kind is unknown;
- the packet refers to the local peer id;
- required packet fields are missing or have invalid types.

Malformed packets do not crash the service.

### Peer and endpoint handling

Announces are parsed into core `Peer`, `Endpoint`, and `DiscoveredPeer` objects.

Peer handling:

- Requires a non-empty string peer id.
- Accepts `name` as `str | None`.
- Preserves peer metadata when it is a JSON object.
- Ignores announces from the local peer.

Endpoint handling:

- Keeps only endpoints with `transport == "lan"`.
- Keeps addresses as strings in `tcp://HOST:PORT` format.
- Uses `parse_tcp_address()` from `paqto.lan.address` for validation.
- Discards invalid announced endpoints.
- Preserves endpoint metadata when it is a JSON object.

Discovery cache behavior:

- Peers are deduplicated by `peer.id`.
- New peers create a new `DiscoveredPeer`.
- Existing peers are updated in place with the latest peer data, endpoints, and discovery metadata.
- Existing peers call `touch()` to refresh `last_seen`.

### Interaction with existing Paqto components

The implementation depends on existing core types:

- `Peer`
- `Endpoint`
- `DiscoveredPeer`
- `DiscoveryService`
- `DiscoveryError`

It also reuses existing LAN address validation:

- `TRANSPORT_NAME`
- `parse_tcp_address()`

No TCP connections are opened by discovery. No application `Message` objects are serialized, deserialized, sent, or received. No user message handlers are called. This keeps discovery separate from the LAN TCP transport while still publishing TCP endpoints that the existing `LanTransport` can later connect to.

### Existing APIs changed

No core abstract APIs were changed.

The only public export change is that `paqto.lan.LanDiscovery` is now available from the LAN package.

## 5. Tests and validation

No automated test files were added or updated.

Validation commands/checks run:

- `python -m compileall src\paqto`
  - Result: passed.

- `PYTHONPATH=src` import check for `from paqto.lan import LanDiscovery`
  - Result: passed.

- Ad hoc async validation with two `LanDiscovery` instances sharing one UDP discovery port.
  - Result: passed.
  - Confirmed that a discovery request from one instance found the other peer.
  - Confirmed that peer name, peer metadata, endpoint address, and endpoint metadata were preserved.

- Ad hoc malformed packet and invalid endpoint validation.
  - Result: passed.
  - Confirmed invalid JSON did not crash the service.
  - Confirmed invalid endpoint addresses were discarded.

- Ad hoc integration validation through `PaqtoNode.discover()` using two nodes with real `LanTransport` listeners and `LanDiscovery` instances.
  - Result: passed.
  - Confirmed the node-level discovery path found the remote node and returned its LAN TCP endpoint.

Not tested or not fully validated:

- No committed pytest or unittest coverage was added.
- No physical multi-machine LAN test was run.
- No IPv6 discovery behavior was tested because the implementation is explicitly IPv4 UDP broadcast.
- No cross-platform validation was run for socket option differences beyond the local environment.
- No high-volume discovery traffic or long-running soak test was performed.

## 6. Known limitations and follow-up work

- Discovery is IPv4 UDP broadcast only.
- There is no IPv6, multicast, mDNS, or per-interface broadcast enumeration.
- There is no peer expiration or TTL while the service is running; discovered peers remain cached until updated or until `stop()` clears the cache.
- `discover()` waits for the bounded collection window rather than returning early when the first peer arrives.
- Discovery packets are unauthenticated and unsigned, so a LAN peer can spoof announces.
- Invalid announced endpoints are discarded; an announce containing only invalid endpoints can still create or update a discovered peer with an empty endpoint list.
- No formal automated test suite was added for the new discovery behavior.
- Future work should add unit tests for packet parsing and integration tests for multi-instance discovery.
