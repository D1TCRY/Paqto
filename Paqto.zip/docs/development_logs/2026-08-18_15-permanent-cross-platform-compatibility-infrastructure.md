# Permanent cross-platform compatibility infrastructure

Date: 2026-08-18  
Runtime used for implementation evidence: Windows 11, CPython 3.14.6, AMD64

## Objective

Create a permanent repository-only compatibility infrastructure under
`compatibility_tests/`, with one discoverable entry point for both single
runtime/device checks and real two-process/two-device LAN interoperability.
The work had to remain outside `src`, outside the Paqto runtime API/wheel, fully
offline, framework-agnostic, and free of platform-specific runtime behavior.

No commit or push was performed.

## Baseline and material inspected

The complete repository file inventory, README, `docs/platform-support.md`,
`docs/platform-testing.md`, all existing `platform_conformance` modules and
fixtures, `tools/two_device_interop.py`, portability development logs 10-14,
`pyproject.toml`, CI configuration, all runtime modules, all test modules, Git
status/diff, and generated build metadata policy were inspected.

The initial worktree already contained user-owned deletions of tracked
`src/paqto.egg-info` and CPython 3.13 bytecode, plus untracked `send.zip`.
Those changes were preserved. The initial ordinary suite passed 180 tests.
Initial Ruff and mypy checks passed; initial full conformance passed 14/14.

## Architecture chosen

`compatibility_tests/run.py` is the sole primary CLI. It has two subcommands:

- `solo`: one OS/Python/Paqto runtime, using the existing deterministic/local
  conformance coverage;
- `pair`: the same CLI on server and client processes/devices, with separate
  `direct` and `discovery` scenarios.

Shared code is split narrowly into result models, platform/package metadata,
JSON reporting, and one compatibility serializer. Pair-only coordination is
an application-level test protocol; no compatibility metadata enters the Paqto
wire protocol or runtime package.

Setuptools still discovers only `src/paqto*`. The built wheel was inspected and
contained Paqto runtime files, dist-info, and the licence only: no
`compatibility_tests`, `platform_conformance`, tests, fixtures, or tools.

## Relationship with `platform_conformance`

The existing 14 conformance checks were moved to
`compatibility_tests/solo/checks.py`; they were not copied or independently
reimplemented. Shared models moved beside them. `platform_conformance/checks.py`,
`models.py`, and `runner.py` are thin compatibility shims delegating to the new
implementation. `python -m platform_conformance` remains usable.

The previous independent implementation in `tools/two_device_interop.py` was
replaced with a deprecated path alias that forwards to the maintained `pair`
subcommand. There is therefore one pair implementation and one solo check set.

## Final directory

```text
compatibility_tests/
  run.py
  README.md
  common/
    models.py
    package_info.py
    platform_info.py
    reporting.py
    serializer.py
  solo/
    checks.py
    runner.py
  pair/
    protocol.py
    runner.py
  fixtures/
    README.md
    tls/
      README.md
      ca.pem
      node-a.pem
      node-a-key.pem
      node-b.pem
      node-b-key.pem
  reports/
    .gitignore
```

## Solo mode

`python compatibility_tests/run.py solo` automatically identifies the runtime,
runs the full local profile, prints a compact result, writes schema-v2 JSON,
and returns 0/1/2 for PASS/FAIL/INCOMPLETE. Existing checks cover import/Python,
serializer/router, Paqto lifecycle, IPv4/IPv6 TCP/UDP capability, framing,
fresh reconnect, local broadcast discovery, NoDiscovery/direct endpoints,
custom/in-memory CA, hostname verification, injected SSLContext, mTLS, strict
identity binding, READY, messaging/ACK/request/reply/concurrency/timeout/
cancellation, limits, resource events, and cleanup.

The report includes Paqto distribution metadata and the resolved
`paqto.__file__`. Source/editable imports are visibly warned. The optional
`--require-installed` check was exercised against the current editable/source
import and correctly returned FAIL/exit 1; it is not imposed on development
runs.

## Platform detection

Detection reports OS family, kernel/system, release, architecture,
`sys.platform`, Python implementation/version, and Android API level when
available. Android classification checks `sys.getandroidapilevel()`, Android
`sys.platform`/`platform.system()` values, and a conservative two-variable
Android runtime environment fallback so Android is not blindly reported as
Linux. This code exists only in compatibility tooling.

Unit tests simulate Android, Windows, Linux, macOS, and another environment.
No hostname, username, device id, or unrelated personal metadata is collected.

## JSON reporting

Every main CLI execution writes JSON under `compatibility_tests/reports/` by
default, with a readable timestamp/OS/architecture/Python/mode name. `--json`
overrides the path. Schema 2 includes generation time, mode/profile or pair
scenario/role, status, platform/Python/Paqto metadata, capabilities, per-check
status/duration, totals, warnings, and total duration.

Pair reports add local and validated remote metadata plus one shared
server-generated UUID `session_id`. Private key/certificate contents and test
payload bodies are never placed in reports. Generated JSON is ignored by Git;
the report directory itself remains tracked through `.gitignore`.

## Pair direct scenario

Direct mode creates `NoDiscovery` nodes. The client uses the explicit
`--target` and `--port`; the server prints bind address, listening port, public
test identity, and waiting state. Both processes use finite deadlines.

After mTLS, strict URI-SAN/peer-id binding, Paqto handshake, and READY, the
application-level suite exchanges minimal platform/Python/Paqto/capability
metadata. It then verifies bidirectional send, bidirectional request/reply,
technical ACKs, multiple and concurrent requests, a hashed reasonable-size
payload, controlled disconnect, a distinct connection, new TLS/mTLS, a
distinct Paqto READY session, post-reconnect request/reply, and cleanup.

Final two-process loopback direct result:

- server: PASS;
- client: PASS;
- shared session: `97bf15b2-f3a0-47e5-8ac3-ac36bad95229`;
- cross-device discovery: deliberately SKIP in direct mode.

This validates the harness and separate OS processes, not cross-platform
hardware.

## Pair discovery scenario

Discovery mode starts real `LanDiscovery` on both roles, requires a reachable
advertised address when binding a wildcard, and never falls back to direct
addressing. Each process must observe the correct remote peer id and announced
LAN endpoint. The client establishes the TCP/mTLS/Paqto session from the
discovery result, after which the complete pair sequence runs.

Final two-process same-host discovery result:

- server: PASS;
- client: PASS;
- cross-process local broadcast discovery: PASS on both;
- shared session: `e3af1265-537c-49d5-8869-a2cafe39e8bc`.

This remains a same-host Windows result. It does not claim cross-device
broadcast or Android evidence.

## TLS test fixtures

The existing CA and node credentials were moved to
`compatibility_tests/fixtures/tls/`. Their README is explicitly headed
`PUBLIC TEST-ONLY TLS MATERIAL — DO NOT USE IN PRODUCTION`. The keys are public
and provide no secrecy. Node certificates contain fixed test URI identities
for `node-a` and `node-b`, plus loopback SAN coverage used by solo hostname
verification.

Arbitrary dynamic private LAN IPs cannot all be encoded in fixed fixtures.
Pair mode therefore performs verified custom-CA mTLS and strict logical
identity binding without claiming dynamic-IP hostname coverage; solo mode
separately proves hostname validation.

## Automatic tests added

The normal pytest suite now verifies:

- platform classification and simulated Android/Windows/Linux/macOS;
- conservative Android environment indicators;
- JSON round-trip and deterministic filenames;
- CLI parsing/validation and stable exit-code propagation;
- server/client fixed test identities;
- metadata validation and remote metadata retention;
- matching/mismatching session ids;
- malformed pair messages;
- explicit remote failure propagation;
- finite pair wait timeout;
- schema-v2 compatibility report aggregation.

## Runtime package modifications

None. No file under `src/paqto/` was modified by this work. A final
case-insensitive scan found no Android, Flet, Flutter, Termux, Chaquopy,
Windows-specific hack, Windows API, Win32, or application-domain reference in
the runtime package.

## Commands and final results

- `python -m pytest -q`: **209 passed**; one environment-only pytest cache
  warning because this workspace cannot create `.pytest_cache`.
- `python -m ruff check src tests examples compatibility_tests
  platform_conformance tools`: passed.
- `python -m mypy src compatibility_tests platform_conformance tools`: passed,
  47 source files.
- `python -m compileall -q src tests examples compatibility_tests
  platform_conformance tools`: passed.
- `python -m pip check`: no broken requirements.
- `python -m build`: the sandboxed isolated-venv attempt was denied permission
  under the host temporary directory; the approved isolated build then passed
  and produced both sdist and wheel.
- wheel archive listing: compatibility/test/tooling paths absent.
- `python compatibility_tests/run.py solo`: PASS, 14 passed, 0 failed,
  0 skipped, 0 unavailable.
- `python -m platform_conformance --profile ci`: compatibility alias passed,
  13 PASS and one deliberate discovery SKIP.
- pair direct with two distinct processes: PASS/PASS and matching session id.
- pair discovery with two distinct processes: PASS/PASS and matching session
  id.
- `git diff --check`: passed; Git emitted only line-ending conversion warnings.

Build/compile regenerated the already-deleted tracked egg-info/bytecode; only
those exact pre-existing deletion paths were removed again after validation.

## Current-machine limits

- No Android, Linux, or macOS runtime was executed.
- Both final pair roles ran on the same Windows machine and Python 3.14.6.
- Same-host discovery does not prove router, Wi-Fi/Ethernet, AP isolation,
  firewall, subnet broadcast, or two physical interfaces/devices.
- No real cross-version pair was available.
- The documented Wi-Fi OFF/ON test remains manual and is not represented as an
  automated PASS.
- Default platform trust stores and production certificates are deliberately
  outside this deterministic fixture suite.

