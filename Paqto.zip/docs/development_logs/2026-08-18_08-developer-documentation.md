# Developer documentation phase

Date: 2026-08-18  
Scope: current Paqto repository documentation after the independent audit

## Objective

Create a navigable, developer-oriented Markdown documentation set for the
current async-first, domain-agnostic implementation. The runtime code and
verified tests were treated as the source of truth. Historical development
logs were retained unchanged.

No commit or push was performed.

## Initial repository state

The worktree was already extensively modified before this phase. Existing
changes included the complete foundation, TLS, protocol, request/reply,
reliability, hardening, and audit work, plus a pre-existing `.gitignore`
modification. All code, tests, package metadata, and unrelated changes were
preserved.

The pre-documentation full test run passed:

```text
python -m pytest
148 passed in 2.38s
```

## Repository areas inspected

- `README.md` and `pyproject.toml`;
- every Python module under `src/paqto/` and `src/paqto/lan/`;
- root/core/LAN public exports and compatibility imports;
- all public models, enums, exceptions, abstract contracts, managers, routers,
  events, protocol controls, security snapshots, configuration objects, and
  LAN address helpers;
- the complete `PaqtoNode` startup, negotiation, READY, messaging, heartbeat,
  reconnect, error, and shutdown paths;
- `examples/lan_two_nodes.py`;
- every test under `tests/core/`, `tests/lan/`, and `tests/integration/`;
- certificate-fixture policy documentation;
- all files in `docs/development_logs/`, reconstructed chronologically as the
  three 2026-05-17 LAN phases followed by 2026-08-18 phases 01 through 07;
- the final independent full-repository audit and its residual findings;
- the complete worktree status before and after documentation changes.

## Documentation files created

- `docs/index.md`
- `docs/getting-started.md`
- `docs/architecture.md`
- `docs/configuration.md`
- `docs/messaging.md`
- `docs/protocol.md`
- `docs/discovery.md`
- `docs/transports.md`
- `docs/security.md`
- `docs/reliability.md`
- `docs/events-and-errors.md`
- `docs/api-overview.md`
- `docs/production.md`
- `docs/development_logs/2026-08-18_08-developer-documentation.md`

## Files modified

- `README.md`
  - Reworked the existing long feature narrative into a concise landing page.
  - Preserved the useful project overview, LAN usage direction, security status,
    guarantee boundary, and runnable-example link.
  - Added navigation to the detailed documentation set.

No runtime source, test, example, project configuration, package metadata,
`.gitignore`, or historical development log was modified in this phase.

## Major documentation decisions

- Used `Peer` for stable logical identity, `Endpoint` for a transport route,
  `DiscoveredPeer` for an untrusted timestamped reachability observation, and
  `authenticated_peer_id` only for an identity established by transport
  security.
- Used READY strictly for a connection that completed the Paqto hello and all
  configured identity checks.
- Kept transport write, Paqto technical acknowledgement, handler execution, and
  application-defined success as separate stages.
- Described reconnect as session recreation, never message retry or trust-state
  reuse.
- Described limits as counts and per-item limits, not as an aggregate memory
  budget.
- Kept authentication separate from application authorization.
- Marked discovery metadata and protocol metadata as generic but untrusted
  unless another mechanism establishes trust.
- Used Mermaid only for the component relationship, session establishment, and
  logical connection state, where the relationships are clearer visually.

## Discrepancies and historical differences found

- The pre-phase README had become a comprehensive accumulation of implementation
  notes. Its claims were largely current, but it was too large for a landing
  page; those details were verified against code/tests and moved into focused
  guides.
- The earliest LAN transport log records a default frame limit of exactly 16
  MiB. Current code uses 16 MiB plus one byte so the default maximum serialized
  application message fits with the Paqto frame-kind marker.
- The early discovery log states that there was no TTL or cache limit. Current
  `LanDiscovery` has a 60-second default TTL and a 1024-peer admission limit,
  and the node applies a separate freshness policy.
- Early security/protocol logs list incoming identity binding, reconnect,
  events, and resource admission as future work. Those features now exist and
  are tested; the historical statements were not copied into current docs.
- The request/reply phase initially described one supervised task per message.
  Current code uses a bounded node-wide queue and fixed handler-worker pool.
- The final independent audit matches current behavior and remains the primary
  source for documented residual production concerns.
- `pyproject.toml` configures pytest but not Ruff or mypy. Both tools were
  available and were run as additional validation.

## Commands executed and results

Inspection and baseline:

```text
git status --short
rg --files ...
python -m pytest
148 passed in 2.38s
```

Final validation:

```text
python -m pytest
148 passed in 2.43s; final verification rerun: 148 passed in 2.35s

python -m ruff check src tests examples
All checks passed!

python -m mypy src
Success: no issues found in 27 source files

python -m compileall -q src tests examples
passed

python examples/lan_two_nodes.py
passed; the greeting was delivered

git diff --check
passed; Git emitted only existing Windows LF/CRLF conversion warnings
```

Documentation-specific checks:

- checked all relative links in `README.md` and the 13 public files under
  `docs/`; all file targets exist;
- manually compared the four cross-file anchors with their actual headings;
- compiled all 16 Python fenced blocks, allowing top-level `await` in excerpts;
- introspected the real `PaqtoNode` send/request/reply signatures and LAN/TLS
  constructor signatures;
- verified that the configuration reference mentions all 50 relevant node,
  reconnect, transport, discovery, and TLS option names;
- searched for removed message-method and retired-constructor references; no
  stale API usage was found;
- scanned public documentation for delivery/security overclaims and confirmed
  occurrences are explicit non-guarantees or warnings;
- scanned public documentation for application-domain vocabulary; no prohibited
  application-domain concepts were found;
- scanned public documentation for private-key block markers and test-key file
  names; none were found.

## Unresolved documentation gaps

- The strict TLS example is close to executable but necessarily requires
  deployment-provided certificates whose SAN identity and endpoint hostname
  match the documented resolver/profile.
- Automated tests intentionally use deterministic loopback and injected
  discovery observations. Real multi-host broadcast behavior still depends on
  interfaces, firewalls, and OS behavior and needs deployment testing.
- No dedicated Markdown linter or repository link checker is configured; this
  phase used a local relative-target check and manual anchor verification.
- A formal cross-language Paqto v1 wire specification and conformance vectors do
  not yet exist, so the protocol guide documents only the current Python
  implementation and does not promise independent-implementation stability.
- Validation used the available Python 3.14.6 interpreter. The declared Python
  3.10 lower bound still needs real multi-version CI, as noted by the audit.
