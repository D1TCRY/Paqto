# Portability audit and capability contract

Date: 2026-08-18  
Scope: complete current Paqto repository, with implementation limited to small
structural portability corrections

## Objective and constraints

Audit the real library for implicit operating-system, network, filesystem,
event-loop, address, DNS, TLS, and lifecycle assumptions. The work retained a
generic cross-platform core and introduced no application-domain or UI-runtime
concept. Discovery, TLS, and node lifecycle were not rewritten.

No commit or push was performed. Previous development logs were read in
chronological order and left unchanged.

## Baseline

- Branch: `main`, tracking `origin/main`.
- Initial worktree: clean.
- Runtime: Python 3.14.6 on the available Windows host.
- Initial suite: `148 passed in 2.35s`.
- Initial development-mode suite: `148 passed in 2.37s`, with warnings treated
  as errors.
- Ruff: all checks passed.
- Mypy: no issues in 27 source files.
- Compileall: passed for `src`, `tests`, and `examples`.
- `pip check`: no broken requirements.
- Runnable two-node example: passed.
- `git diff --check`: passed.
- Isolated sdist/wheel build: passed after permission was granted for the
  temporary build environment. The first sandboxed attempt failed only because
  it could not create the temporary virtual environment.

The build regenerated tracked `src/paqto.egg-info/PKG-INFO`; that generated,
out-of-scope change was restored to the clean baseline version.

## Material inspected

- root metadata, license, ignore policy, build/publish wrappers, package
  metadata, Git status, and complete diff;
- README and every current document under `docs`;
- all 12 earlier development logs, ordered by their actual creation times;
- all 27 Python source modules, including core, LAN TCP/UDP, TLS, protocol,
  connection management, lifecycle, timeout/cancellation, and logging paths;
- every core, LAN, TLS, and integration test plus test fixture policy;
- the complete runnable example.

The implementation, not historical logs, was treated as the source of truth.

## Reconstructed architecture

The core is capability-oriented: `PaqtoNode` coordinates abstract
`Transport`, `Listener`, `Connection`, `DiscoveryService`, and `Serializer`
contracts. TCP, IPv4 UDP broadcast, and TLS are confined to `paqto.lan`.
`ConnectionManager` owns canonical READY connections and single-flight setup.
The node owns asyncio tasks, monotonic-loop heartbeat activity, reconnect,
bounded queues, correlation, events, logging, and cooperative shutdown.

The core imports no socket, SSL, filesystem, signal, thread, process, interface,
or platform API. The LAN adapter is optional and narrower than the core.

## Platforms and environments considered

- supported Python versions 3.10 through 3.14;
- Linux, macOS, and Windows networking/event-loop behavior;
- IPv4, IPv6-only, and dual-stack hosts;
- isolated LANs without Internet or a default Internet route;
- hosts without usable DNS/hostname resolution;
- multi-homed and dynamically changing networks;
- sandboxed/mobile runtimes with operating-system network permissions;
- restricted filesystems and differing TLS trust stores/backends.

Only the available Windows/Python 3.14 runtime was executed. The rest remains a
real-runtime validation matrix, not a claimed result.

## Findings and classification

### A — real cross-platform bugs

1. Wildcard IPv6 listeners used the same IPv4-oriented advertised-address
   heuristic as IPv4. Whether the resulting IPv4 endpoint reached an IPv6 bind
   depended on platform dual-stack behavior. Fixed by family-matched local
   resolution and regression coverage.
2. `ReconnectPolicy.delay_for_attempt()` could raise `OverflowError` after an
   extreme number of indefinite exponential attempts, terminating the
   reconnect supervisor. Fixed by saturating at `maximum_delay`; a 10,000th
   attempt regression test passes.

### B — platform-dependent behavior to abstract or configure

1. Wildcard advertised-host selection opened a UDP socket connected to
   `8.8.8.8:80`. Although no datagram was sent, route selection depended on a
   conventional Internet destination. Removed. `advertised_host` now permits
   explicit value injection and automatic fallback uses local hostname
   resolution only.
2. Automatic address selection remains ambiguous on multi-interface hosts.
   Explicit advertisement is required when topology matters.
3. A node publishes one listener endpoint. Discovery already accepts a
   sequence, but plural/per-interface listener advertisement needs a later
   capability-oriented contract.
4. `LanDiscovery` is intentionally IPv4 UDP broadcast. Bind, broadcast,
   address reuse, and delivery semantics differ across stacks.
5. Discovery freshness uses a wall-clock `datetime`; core timeouts and
   heartbeat activity use monotonic asyncio clocks. A future discovery model
   should separate diagnostic timestamps from local monotonic age.
6. TLS material is currently file-path based and optional trust defaults use
   the runtime system store. Future context/material providers would support
   more restricted environments without platform-named classes.
7. Advertised addresses are snapshots made at listener start; interface churn
   needs host policy or future adapter support.
8. Root batch files are platform-specific development wrappers. They do not
   enter the wheel or runtime; portable automation should use Python module
   commands directly.

### C — host responsibilities, not Paqto implementation work

- operating-system network permissions, foreground/background policy,
  firewalls, segmentation, and connection flood controls;
- selecting a reachable bind/advertised route and deciding whether DNS or
  provisioned numeric endpoints are available;
- certificate issuance, protected storage, rotation, revocation, trust policy,
  and application authorization;
- process-wide event-loop policy, logging handlers/storage, cooperative
  handlers, and explicit offloading of blocking work;
- durable messaging, retries, idempotency, transactions, and application
  success semantics.

### D — requires real hardware/runtime validation

- the Python 3.10-3.14 and Linux/macOS/Windows matrix;
- IPv4, IPv6-only, dual-stack, scoped/link-local, and multiple-interface TCP;
- a LAN with no Internet route and no DNS service;
- UDP broadcast, reuse options, firewall, and sandbox behavior;
- interface/address changes and suspend/resume;
- TLS system stores, backend error types, handshake/shutdown behavior;
- cancellation and socket error normalization on slow, lossy, or abruptly
  disconnected real networks.

Routine tests use IPv4 loopback and injected discovery datagrams, so they do
not establish these real-environment results.

## Portability contract added

`docs/platform-support.md` now states that the generic core requires only
Python 3.10+, standard asyncio, cooperative adapters, and monotonic scheduling
for operational deadlines. TCP belongs to `LanTransport`; IPv4 UDP broadcast
belongs to `LanDiscovery`; TLS/filesystem material is optional and configured.
Internet, DNS, stable IP addresses, interface names, signals, file descriptors,
threads, processes, and a particular UI/runtime environment are not core
requirements.

The document separates portable library code, optional adapters, host
responsibilities, and validation requiring real platforms or hardware.

## Changes applied

Runtime:

- removed the `8.8.8.8` UDP-connect local-address heuristic;
- added optional `advertised_host` injection to `LanTransport` and
  `TcpListener`;
- made automatic wildcard resolution address-family aware;
- made reconnect delay calculation saturate safely after numeric overflow.

Tests:

- verified address selection creates no probe socket;
- verified explicit advertised-host injection bypasses resolution;
- verified an IPv6 wildcard requests/resolves IPv6 rather than IPv4;
- verified the transport passes explicit advertisement to its listener;
- verified extreme reconnect attempt counts remain bounded.

Documentation:

- added `docs/platform-support.md` and navigation links;
- updated LAN transport/configuration behavior and production cross-reference;
- created this development log without modifying earlier logs.

## Final validation

- `python -m pytest -q`: `153 passed`;
- `python -X dev -m pytest -q -W error`: `153 passed`, no warning;
- `python -m ruff check src tests examples`: passed;
- `python -m mypy src`: passed, 27 source files;
- `python -m compileall -q src tests examples`: passed;
- Python 3.10 grammar parse for all source modules: passed;
- `python -m pip check`: passed;
- `python examples/lan_two_nodes.py`: passed;
- isolated `python -m build`: sdist and wheel passed;
- documentation relative-link check: passed;
- `git diff --check`: passed.

## Risks and compatibility

- `advertised_host` is optional and appended to constructor signatures, so
  existing calls remain source-compatible.
- Default wildcard advertisement may now differ from the former route-probe
  result. If hostname resolution cannot find a suitable local address, the
  wildcard is exposed rather than guessing from an Internet route. Hosts that
  need a reachable route should inject it explicitly.
- Automatic hostname resolution can still be ambiguous and is not an identity
  or trust mechanism.
- No claim is made for real IPv6, multi-host broadcast, alternative platform
  TLS stores, or the supported Python matrix until those environments run.

## Recommended roadmap

1. Add supported-Python CI on Linux, macOS, and Windows.
2. Add opt-in offline-LAN, IPv6-only/dual-stack, and multi-interface tests.
3. Design plural advertised endpoints without interface-name assumptions.
4. Separate discovery wall timestamps from monotonic local freshness.
5. Add injected TLS context/material providers for restricted filesystems.
6. Characterize platform socket/TLS cancellation errors with fault injection
   before broadening normalization.
7. Keep all future APIs capability-oriented and generic; do not add
   operating-system-specific core classes.
