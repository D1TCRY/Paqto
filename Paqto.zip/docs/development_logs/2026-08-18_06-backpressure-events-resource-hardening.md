# Backpressure, Event Observability, and Resource Hardening

## Phase objective

Prevent slow or faulty application handlers, slow transports, and excessive
message/connection flows from creating unbounded node state or destabilizing
unrelated Paqto lifecycle machinery. This phase adds bounded dispatch and write
paths, handler isolation with an explicit policy, generic lifecycle events,
structured logging, resource admission limits, and restart/shutdown coverage.

The implementation remains transport-agnostic and domain-agnostic. It adds no
application semantics, durable queue, retry, deduplication, authorization role,
or proprietary cryptography.

## Initial state

- The current uncommitted worktree from the foundation, TLS, handshake,
  request/reply, and fault-tolerance phases was treated as the source of truth.
- Every development log was reread, with particular attention to phases 03-05.
- `PaqtoNode`, `MessageRouter`, connection reader/writer paths, TCP flow
  control, listener acceptance, request/ACK correlation, heartbeat, reconnect,
  discovery TTL, configuration, public exports, and shutdown ownership were
  traced before editing.
- Git status contained all prior phase changes and the pre-existing user
  modification to `.gitignore`. No unrelated user change was overwritten.
- `docs/development_logs/` remains ignored by the existing `.gitignore` rule.
  Previous logs and Git policy were not changed.
- Baseline command: `python -X dev -m pytest -q -W error`.
- Baseline result: `98 passed in 1.63s`, with no asyncio/resource warning.

## Problems found

1. Handler exceptions did **not** currently terminate the network reader,
   because each inbound application message was dispatched in a separate task.
   However, the task exception was merely retrieved and otherwise invisible.
2. Creating one task per application message was unbounded. A slow handler or
   sustained inbound stream could grow `_handler_tasks` and memory without a
   fixed ceiling.
3. Concurrent sends were serialized by `TcpConnection._send_lock`, but the
   number of coroutines waiting for that lock was unbounded. This was an
   implicit outbound queue with no admission policy.
4. Incoming handshakes and physical connections had no node-level admission
   limit.
5. Pending request and acknowledgement maps had unconditional cleanup but no
   configurable capacity.
6. Background handler failures, handshake/protocol failures, connection state,
   authentication, resource rejection, and discovery freshness changes had no
   general public observation API.
7. Logging did not provide a consistent peer/session/correlation context.
8. A READY connection had heartbeat failure detection but no independent idle
   receive limit.
9. LAN frame-size configuration accepted zero and did not normalize invalid
   non-integer values at construction.

## Backpressure model

### Inbound

The READY reader continues to process and validate protocol/control frames
itself. Valid non-reply application messages cross one node-wide bounded FIFO
queue before handler dispatch. A fixed `handler_concurrency` pool consumes that
queue; there is no longer one task per message.

The default `BackpressurePolicy.WAIT` awaits a free queue slot. Pressure then
propagates to the exact connection reader and ultimately to transport flow
control without increasing memory indefinitely. `REJECT` reports a resource
limit and terminates the excessive inbound session. Queue capacity is
`max_inbound_queue`.

Workers start messages in FIFO dequeue order, but multiple workers mean handler
completion order is intentionally not guaranteed. `MessageRouter` still invokes
the matching handler list in its registered order for one message.

### Outbound

Every READY physical connection owns one bounded outbound queue and exactly one
writer task. Application frames, ACK, PING, and PONG use that path, preserving
their per-connection frame order. Handshake frames remain direct because the
READY channel does not exist until negotiation succeeds.

`BackpressurePolicy.WAIT` is also the outbound default. `REJECT` raises
`ResourceLimitError` to the sending operation when the per-connection queue is
full. `max_outbound_queue` is per READY connection; total queued frames remain
bounded by it and `max_connections`.

These queues are volatile. Cancellation, timeout, connection loss, or shutdown
does not imply that a frame already handed to an operating-system stream was
unsent, and Paqto still provides no durable delivery or automatic retry.

### Diagnostic events

The event queue is also bounded, but has deliberately different semantics:
events must never stall network processing. `_emit_event()` uses non-blocking
admission; a full `max_event_queue` drops the observation and writes a warning.
Events are diagnostics, not a reliable audit log.

## Handler error isolation

`MessageRouter` continues to normalize ordinary handler failures as
`MessageRoutingError`. Dispatch workers catch that boundary, emit
`HANDLER_ERROR`, and log generic identity/type context without payload data.

`HandlerErrorPolicy` is public:

- `CONTINUE` (default): retain the connection and process later messages;
- `CLOSE_CONNECTION`: close only the physical connection associated with the
  failing message, allowing normal cleanup/reconnect policy to run.

The failure is therefore never silent and does not normally become a network
failure. A worker that terminates unexpectedly is supervised and replaced while
the node is running. Shutdown does not replace cancelled workers.

## Resource limits

New `PaqtoConfig` options:

- `max_pending_requests=1024`;
- `max_pending_acknowledgements=1024`;
- `max_inbound_queue=256`;
- `max_outbound_queue=256` per READY connection;
- `max_event_queue=256`;
- `max_connections=128`, counting admitted inbound/outbound physical
  connections including inbound negotiation;
- `handler_concurrency=4`;
- `idle_timeout=None` (disabled by default);
- `inbound_backpressure=BackpressurePolicy.WAIT`;
- `outbound_backpressure=BackpressurePolicy.WAIT`;
- `handler_error_policy=HandlerErrorPolicy.CONTINUE`.

All capacities require positive non-boolean integers. Timeouts retain positive,
finite validation. Exceeding a pending-correlation, queue, or connection limit
raises/reports public `ResourceLimitError` as appropriate.

Limits already present and retained:

- `max_message_size` is negotiated at the Paqto protocol layer;
- `handshake_timeout`, connect/send/request/ACK/heartbeat timeouts remain
  independently bounded;
- `LanTransport.max_frame_size` bounds the complete TCP frame and is enforced
  on send and receive.

LAN `max_frame_size` now requires a positive, non-boolean integer no larger
than the unsigned four-byte framing range. The transport frame and negotiated
message limits remain separate because the core cannot assume a concrete
transport framing overhead.

`idle_timeout` wraps READY-state frame receive. An expiry closes that session,
fails its exact-session pending state, emits the normal disconnected lifecycle,
and may reconnect. Heartbeat frames count as activity. When heartbeat and idle
timeout are both enabled, configuration must allow enough idle budget for the
chosen interval/response policy.

## Event model

Public API:

- `NodeEventType`;
- immutable `NodeEvent` with timestamp, local/remote peer id, opaque
  connection id, optional error, and immutable generic metadata;
- `EventHandler` and `EventRouter`;
- `PaqtoNode.on_event(type=None)` for sync or async callbacks.

Events cover:

- peer discovered and freshness expiry observations;
- connecting, connected, and reconnecting;
- transport authentication (with explicit `authenticated_peer_id` and
  `peer_id_authenticated` metadata so certificate authentication is not
  confused with logical peer-id binding);
- disconnected;
- protocol/session processing error;
- application handler error;
- resource-limit rejection.

Discovery expiry is evaluated when discover/connect/reconnect work rechecks a
peer. No background authorization role was added to discovery. One failing
event listener is returned as an isolated listener error, logged, and does not
prevent later listeners or network processing.

## Structured logging policy

The implementation uses Python's standard `logging` hierarchy (`paqto.core.node`)
and no direct printing. Records include relevant structured `extra` keys such
as:

- `paqto_local_peer_id`;
- `paqto_peer_id`;
- `paqto_connection_id`;
- `paqto_reconnecting` / authentication state;
- `paqto_message_id`, `paqto_message_type`, and request correlation id;
- `paqto_event_type`;
- `paqto_error_type`.

Connection attempts, READY/disconnect transitions, reconnect attempts,
handshake/session failures, request registration/resolution, handler failures,
listener failures, and limit rejection now have diagnostic records. Payloads,
headers, serialized bytes, certificates, credentials, and exception text are
not logged by default. The actual exception remains available to an explicit
event listener.

## Lifecycle and cleanup

On every successful start, PaqtoNode creates fresh inbound/event queues, a
fixed dispatch pool, an event consumer, and the accept task. Stop is idempotent
and the same LAN node may be started again after a completed stop.

Shutdown now cancels/gathers:

- accept and connection readers;
- fixed dispatch workers;
- the event consumer;
- per-connection writer workers;
- heartbeat and reconnect tasks.

It fails request, ACK, heartbeat, active-frame, and queued-frame futures;
closes all admitted physical connections plus manager/listener/transport
resources; drains queued observations/application work; and clears ownership
registries. A callback that itself calls `stop()` is the current task and is
allowed to unwind after cleanup rather than being awaited by itself; it cannot
re-enter its consumer loop because running state is already false.

## Files modified in this phase

Runtime/public API:

- `src/paqto/core/events.py` (new);
- `src/paqto/core/config.py`;
- `src/paqto/core/errors.py`;
- `src/paqto/core/node.py`;
- `src/paqto/core/__init__.py`;
- `src/paqto/__init__.py`;
- `src/paqto/lan/address.py`;
- `src/paqto.egg-info/SOURCES.txt`.

Tests:

- `tests/core/test_hardening_models.py` (new);
- `tests/integration/test_node_hardening.py` (new).

Documentation:

- `README.md`;
- this ignored development log.

No `.gitignore` policy, previous development log, test credential, commit, or
remote repository was changed by this phase.

## Tests added

Coverage includes:

- positive integer and enum validation for every new limit/policy;
- LAN frame-size limit validation;
- immutable event snapshots and isolated EventRouter failures;
- handler exception observation and default connection survival;
- explicit handler-close policy;
- logging assertions proving handler and payload secret strings are absent;
- one slow handler with a bounded queue and fixed worker count;
- inbound WAIT and REJECT behavior;
- outbound queue rejection while one writer is blocked;
- pending request and pending ACK limit rejection and cleanup;
- malformed application type/header rejection before serialization/send;
- lifecycle events, discovery event, peer-expiry event, and failing event
  callback isolation;
- idle timeout;
- connection admission rejection;
- multiple peers/messages operating within configured limits;
- shutdown with active handlers and queued load;
- LAN start-stop-start-stop lifecycle;
- zero reader/dispatch/event/writer/heartbeat/reconnect/pending state after
  cleanup.

## Validation

Baseline:

- `python -X dev -m pytest -q -W error`
  - passed: `98 passed in 1.63s`.

Intermediate:

- first historical full suite after runtime changes
  - passed: `98 passed in 1.80s`;
- initial new hardening subset
  - passed after correcting only a test's zero-time discovery wrapper;
- expanded hardening subset
  - passed: `25 passed in 0.45s`;
- ten consecutive development-mode runs of
  `tests/integration/test_node_hardening.py`
  - each passed: `14 passed`, with run times between 0.34 and 0.38 seconds;
- `python -m mypy src`
  - passed: no issues in 27 source files;
- `python -m ruff check src tests examples --ignore PYI034`
  - passed.

Final validation after the critical review:

- two consecutive `python -X dev -m pytest -q -W error` runs
  - passed after the final envelope-validation review: `124 passed in 2.05s`
    and `124 passed in 2.06s`;
  - no pending-task, unclosed-stream, unclosed-socket, `ResourceWarning`, or
    unretrieved-Future warning was emitted;
- `python -m mypy src`
  - passed: no issues in 27 source files;
- `python -m ruff check src tests examples --ignore PYI034`
  - passed; the retained ignore is the previously documented Python 3.10
    compatibility choice for `typing.Self` suggestions;
- `python -m compileall -q src tests examples`
  - passed;
- `python -m pip check`
  - passed: no broken requirements;
- public import/default check for backpressure, handler policy, event API,
  resource error, and default capacities
  - passed: `import-ok wait continue connected 256 128 ResourceLimitError`;
- `python examples/lan_two_nodes.py`
  - passed: the fundamental plain-LAN example completed discovery, handshake,
    bounded writer/reader processing, and application delivery;
- `git diff --check`
  - passed with only existing Windows LF-to-CRLF conversion notices;
- `git check-ignore -v` for this log
  - confirmed the unchanged `.gitignore:2:docs/development_logs/` rule;
- prohibited application-domain vocabulary scan across runtime, tests, example,
  README, and this log
  - no match;
- final Git status review
  - prior uncommitted phase work and the user's `.gitignore` change remain;
    this phase added no commit or push.

## Architectural compromises and compatibility

- Handler concurrency was already observable in the previous phase. It is now
  bounded rather than unbounded; code relying on unlimited parallel dispatch
  must configure a suitable finite worker count.
- The inbound queue is node-wide. This creates a clear global memory ceiling
  and simple FIFO admission, but does not promise strict per-peer fairness. A
  future fair scheduler may add per-peer quotas without changing the handler
  API.
- Default WAIT provides lossless in-memory backpressure while the session
  remains alive, but a blocked reader cannot process later control frames on
  that same ordered stream until capacity becomes available. Configurations
  with strict liveness needs should provision concurrency/capacity or use
  REJECT.
- The node can reject an outgoing socket only after the transport has opened it,
  because the generic `Transport.connect()` contract owns physical creation.
  It is closed before negotiation/use and never becomes READY.
- `max_connections=1` can intentionally prevent simultaneous cross-connect
  negotiation; deployments needing duplicate resolution during establishment
  must allow the transient second connection.
- Event delivery is best effort and bounded, not durable. Applications needing
  an audit trail must persist selected events in their own listener.
- A non-restartable custom Transport/Discovery adapter can still prevent reuse
  of the same node instance. Paqto's LAN adapters and node-owned tasks are
  restart-safe and are the tested public implementation.
- LAN `max_frame_size=0` is now rejected at configuration time. Such a transport
  could never carry the mandatory Paqto handshake, so this is intentional
  validation tightening.

## Problems intentionally left open

- There is no strict per-peer fair queueing or per-peer message rate limit.
- A synchronous handler, or async code that never yields, can still block the
  process event loop. Paqto does not silently move arbitrary application code to
  a thread; handlers must use cooperative async I/O or explicitly offload their
  own blocking/CPU work.
- There is no outbound byte-budget; the queue is bounded by frame count and
  every frame is independently bounded by transport/protocol size limits.
- There is no durable event stream, durable message queue, retry, resend,
  deduplication, exactly-once guarantee, or session resumption.
- Events do not expose payloads by design. Applications requiring content-aware
  diagnostics must add that explicitly at their own security boundary.
- Discovery does not proactively push expiry into PaqtoNode; expiry events occur
  when node activity re-evaluates known observations.
- Authentication events report transport authentication separately from
  `peer_id_authenticated`; authentication still does not imply authorization.
- Transport/network-layer SYN backlog, TLS handshake CPU limits, and OS file
  descriptor limits remain deployment concerns outside the generic node API.
- No cross-platform or multi-version CI was available in this workspace.

## Guidance for the next phase

1. Preserve the READY control/application separation and route any new control
   feature through the bounded per-connection writer.
2. If retry/delivery work is added, specify byte budgets, idempotency, deadlines,
   persistence, and session boundaries independently of these volatile queues.
3. Consider per-peer fair admission only with deterministic scheduling tests;
   do not replace the global memory ceiling with unbounded peer queues.
4. Keep event payloads generic and non-sensitive; add durable observability as
   an application adapter rather than making the network reader write storage.
5. Retain exact-connection correlation and fail old-session futures before any
   reconnect can establish new work.
