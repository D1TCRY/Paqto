# Lifecycle and network-change portability

Date: 2026-08-18  
Scope: generic node lifecycle, host-notified network refresh, monotonic timing,
cancellation, reconnect, heartbeat, discovery, and event-loop composition

## Objective and constraints

Make Paqto usable inside a host that owns its application/process lifecycle and
may suspend network access, change routes or addresses, or cancel work. The core
must not assume permanent foreground execution, stable interfaces, permanent
connectivity, process control, or signal-handler authority.

The implementation remains capability-oriented. It adds no operating-system,
UI-runtime, process-manager, interface-enumeration, or application-domain API.
No commit or push was performed.

## Baseline and material reviewed

- Branch: `main`.
- Runtime: Python 3.14.6 on the available Windows host.
- The worktree already contained the uncommitted portability and TLS-context
  phases; those changes were preserved.
- The two preceding portability logs
  (`2026-08-18_10-portability-audit.md` and
  `2026-08-18_11-tls-context-portability.md`) were read in full. The earlier
  lifecycle/fault-tolerance and resource-hardening logs were also checked for
  historical claims, but the implementation and current tests remained the
  source of truth.
- `PaqtoNode`, `ConnectionManager`, `DiscoveredPeer`, `DiscoveryService`,
  `LanDiscovery`, `LanTransport`, `TcpListener`, `TcpConnection`, protocol
  negotiation, TLS setup, request cleanup, heartbeat, reconnect, events,
  examples, tests, documentation, Git status, and the accumulated diff were
  inspected.
- Baseline full suite: `162 passed in 2.69s`.
- Baseline development-mode suite: `162 passed in 2.77s`, warnings as errors.
- Baseline Ruff, mypy (27 source files), compileall, `pip check`, and
  `git diff --check`: passed.

## Reconstructed lifecycle architecture

`PaqtoNode` is an async coordinator inside the host's already-running event
loop. It starts one transport, a fresh listener, discovery, accept/event/handler
workers, and later per-connection reader/writer/heartbeat/reconnect tasks. The
node does not call `asyncio.run()`, create a global loop, change loop policy, or
install signal handlers. The standalone example alone calls `asyncio.run()` at
its process entry point.

`ConnectionManager` owns single-flight outgoing setup and canonical READY
connections. Cancelling one connect waiter intentionally does not cancel a
shared setup task; node shutdown cancels the manager-owned setup. Failed or
cancelled Paqto negotiation closes the physical connection. Request and ACK
correlations use `finally` cleanup. Heartbeat uses the running loop's monotonic
clock; reconnect uses asyncio sleep and bounded backoff.

The built-in LAN transport is restartable and guards against a connection from
an old lifecycle generation being returned after stop/restart. Listeners are
single-use, so each node start creates a new listener and evaluates its
advertised endpoint again.

## Findings and classification

### A — real cross-platform bugs

1. Node discovery with `discover_timeout=0` passed the immediate operation to
   `asyncio.wait_for(..., 0)`. Asyncio cancelled the coroutine before even an
   immediate result could run, contradicting the documented non-blocking
   semantics. Zero now delegates directly to the discovery service.
2. Discovery TTL passage used wall-clock `datetime` subtraction. Clock
   corrections could expire a fresh endpoint early or extend a stale endpoint.
   `last_seen` remains UTC diagnostic data, while normal TTL evaluation now
   uses a local monotonic anchor.
3. Cancelling the task awaiting `PaqtoNode.stop()` could interrupt cleanup at an
   arbitrary await and leave partial ownership state. Stop now runs as an
   atomic lifecycle transition with respect to caller cancellation, completes
   cleanup, then re-raises cancellation.
4. Workers excluded from cancellation because they initiated a lifecycle call
   could otherwise continue into a new network lifecycle. Lifecycle generation
   checks now retire old accept/event/dispatch workers, and old dispatch-worker
   callbacks cannot create replacements in a newer generation.

### B — platform-dependent behavior abstracted/configured

1. The core cannot detect interface, route, address, foreground/background, or
   suspend transitions portably. A new generic `await node.network_changed()`
   notification lets the host report such a transition without exposing any
   platform concept to Paqto.
2. An endpoint is still a listener-time snapshot. Network refresh performs a
   full stop/start, recreates the listener, republishes its current endpoint,
   clears remote endpoint snapshots, and runs discovery again.
3. Previously connected/reconnecting peer ids are retained only as refresh
   intent. If fresh discovery finds them, the normal configured reconnect
   policy schedules entirely new transport/TLS/Paqto sessions. With reconnect
   disabled, the method returns observations for explicit host-directed
   `connect()` calls.

### C — host responsibilities, not Paqto features

- own the process and application lifecycle;
- detect host-specific foreground/background, suspend/resume, permission,
  interface, address, and route changes;
- decide when to call `stop()`, later `start()`, or `network_changed()`;
- grant network permission and comply with sandbox/firewall policy;
- choose topology-specific bind/advertised addresses;
- bound and cancel its own caller tasks when appropriate;
- configure the process event loop, signal handling, threads/processes, and
  logging destinations;
- provide application retry, persistence, idempotency, authorization, and
  durable success semantics.

Paqto cannot bypass a system policy that removes network access. It can close
its resources and rebuild them when the host/runtime and network make the
required capabilities available again.

### D — requires real runtime/hardware validation

- actual background/suspension and network-permission transitions;
- interface removal/addition and address churn on multi-interface hosts;
- Wi-Fi/Ethernet handover, route loss, captive or offline LANs, and DNS changes;
- platform-specific TCP/UDP/TLS cancellation and shutdown errors;
- TLS backend behavior while a runtime suspends sockets;
- supported Python versions and Linux/macOS/Windows event-loop implementations;
- long-duration flaky-network stress with real open-socket inspection.

Loopback and deterministic fake-adapter tests validate orchestration, not these
external runtime behaviors.

## Final lifecycle contract

- `start()` starts one network lifecycle. Calling it while running raises
  `AlreadyStartedError`.
- `stop()` is idempotent, closes all owned volatile resources, clears cached
  discovery reachability, and is cancellation-resilient from the caller's
  perspective.
- A completed `stop()` may be followed by `start()` on the same node when the
  supplied adapters are restartable. The built-in LAN adapters are tested for
  `start/stop/start/stop`.
- A restarted node does not reuse remembered remote endpoints. The host must
  discover again or provide a fresh `DiscoveredPeer`.
- `network_changed()` requires a running node and atomically performs
  stop/start/invalidate/discover. It may finish running, or remain stopped if
  adapter restart fails. If the discovery pass fails after startup, the new
  network lifecycle remains running without stale cached endpoints so the host
  can retry.
- No session, request, ACK, heartbeat challenge, socket, TLS result, or Paqto
  handshake state crosses a lifecycle generation.
- Custom adapters must be restartable for repeated node lifecycle use and must
  cooperate with cancellation/close. Paqto cannot impose a hard deadline on an
  adapter that never returns.

Clearing discovery state on every full stop is an intentional behavioral
tightening: code that previously stopped, restarted, and then connected by a
cached `Peer` must now rediscover or retain/provide a deliberately fresh
`DiscoveredPeer`. This prevents an old network snapshot from being treated as a
current route.

## Clock contract

- asyncio deadlines and sleeps measure durations with the event loop's
  monotonic facilities;
- heartbeat activity uses `loop.time()`;
- reconnect backoff uses asyncio sleep;
- discovery TTL uses a local monotonic observation anchor;
- UTC `Message.created_at`, `NodeEvent.occurred_at`, and
  `DiscoveredPeer.last_seen` remain informational timestamps, not normal
  duration clocks;
- explicit `DiscoveredPeer.freshness(now=...)` remains available for
  deterministic wall-time evaluation and compatibility.

## Cancellation audit

- startup cancellation: partial transport/listener/discovery resources roll
  back;
- discovery cancellation: propagates; a concurrent stop clears node resources
  and generation checks prevent late results from repopulating stale state;
- TCP/TLS setup and Paqto handshake: connection setup is manager-owned and is
  cancelled/closed by node stop;
- request: pending correlation is removed in `finally`;
- heartbeat: pending challenge and task are cancelled on session/node cleanup;
- reconnect: backoff/setup task is cancelled and gathered on stop/refresh;
- stop/network refresh: caller cancellation is delayed until the atomic
  transition reaches a consistent state.

No operating-system-specific network exception was added. `TransportError` and
`DiscoveryError` remain the generic boundaries and preserve underlying causes
where errors are normalized.

## Runtime and test changes

Runtime:

- added `PaqtoNode.network_changed()`;
- refactored start/stop into serialized internal lifecycle operations;
- made stop and network refresh atomic against caller cancellation;
- added lifecycle generations for accept/event/dispatch workers;
- cleared known-peer and stale reconnect diagnostic state on full stop;
- rejected discovery results completed in another lifecycle generation;
- corrected the zero-time discovery path;
- changed operational discovery TTL passage to monotonic time.

Tests cover:

- cancelled startup rollback;
- cancelled stop completing cleanup before cancellation propagation;
- repeated `start/stop/start/stop` in the existing host-managed loop;
- deterministic local and remote endpoint replacement;
- stale endpoint invalidation;
- network disappearance and return under a new remote address;
- reconnect after refresh with a new socket, TLS handshake, Paqto handshake,
  READY session, and application message;
- stop during plain Paqto handshake and during TLS handshake;
- discovery cancellation concurrent with stop;
- cancellation during `network_changed()` discovery while preserving a
  consistent refreshed lifecycle;
- monotonic TTL behavior independent of a simulated wall-clock jump;
- immediate discovery results with a zero timeout;
- cleanup registries containing no reader, writer, heartbeat, reconnect, or
  active-connection residue.

## Validation

- focused lifecycle/fault/discovery/TLS selection: passed;
- ten consecutive development-mode lifecycle-portability runs: each passed,
  with no pending-task, unclosed-stream/socket, unretrieved-Future, or
  `ResourceWarning` output;
- full suite: `175 passed in 2.80s`;
- full development-mode suite with warnings as errors: `175 passed in 2.92s`;
- Ruff: passed;
- mypy: no issues in 27 source files;
- compileall for `src`, `tests`, and `examples`: passed;
- `pip check`, runnable example, Python 3.10 grammar parse, documentation link
  checks, prohibited-vocabulary scan, event-loop/signal scan, and
  `git diff --check`: included in final validation.

## Risks and recommended roadmap

1. Add CI for all supported Python versions on Linux, macOS, and Windows.
2. Add opt-in real-runtime tests for suspend/resume, permission loss, interface
   handover, offline LAN, IPv6, and multi-interface endpoint publication.
3. Consider plural advertised endpoints through a generic capability rather
   than interface-name enumeration in the core.
4. Characterize platform TLS/socket error causes before adding broader generic
   error categories; do not discard original exceptions.
5. Add long-running loss/recovery stress tests with operating-system-level
   socket inspection.
6. Keep lifecycle detection, signal handlers, process ownership, credential
   storage, and system policy in the host boundary.
