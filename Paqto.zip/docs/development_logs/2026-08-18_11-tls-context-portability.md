# TLS context and trust portability

Date: 2026-08-18  
Scope: capability-oriented TLS/mTLS configuration for restricted, embedded,
and non-traditional host environments

## Objective and constraints

Make the existing LAN TLS implementation usable when certificate material and
trust policy are managed by the host rather than by ordinary configurable file
paths. The implementation remains generic and uses only Python's standard
`ssl` and `asyncio` capabilities. It adds no operating-system certificate API,
environment-specific storage integration, application-domain behavior, or
automatic temporary secret files.

No commit or push was performed. Earlier development logs were read and left
unchanged.

## Baseline and material reviewed

- Branch: `main`.
- Runtime: Python 3.14.6 with OpenSSL 3.5.7 on the available Windows host.
- The worktree already contained the uncommitted portability-audit phase. Its
  changes were preserved and treated as the starting source of truth.
- The LAN TLS/security phase log and the portability-audit log were read before
  changes. The implementation, tests, security docs, configuration docs,
  platform contract, and complete Git diff were then checked directly.
- Initial suite: `153 passed in 2.76s`.
- Initial development-mode suite with warnings as errors: `153 passed in
  2.93s`.
- Initial Ruff, mypy, compileall, `pip check`, runnable example, and
  `git diff --check`: passed. Diff checking emitted only line-ending conversion
  warnings.

## Previous TLS API and portability problems

The previous public high-level API was:

```python
LanTransport(
    tls=TlsConfig(
        certfile=...,
        keyfile=...,
        cafile=...,
    )
)
```

`TlsConfig` always built both SSL contexts during `LanTransport.start()`.
`certfile` and `keyfile` were required filesystem paths. Trust either came from
one optional `cafile` or from Python's default store. Although `TcpListener`
could already receive a server context internally, `LanTransport` offered no
public way to inject caller-prepared client and server contexts.

Concrete portability issues:

1. An application managing credentials outside an ordinary filesystem could
   not configure the built-in transport without exposing accessible paths.
2. Custom trust data in memory required host-side context creation or a file,
   but host-side context creation could not be passed to `LanTransport`.
3. The default trust-store behavior varies with Python, its TLS backend, and
   the host; it cannot be treated as identical across platforms.
4. Adding private-key byte input to the path-based API would require unsafe or
   platform-specific workarounds because `SSLContext.load_cert_chain()` accepts
   filenames in the supported standard-library API.
5. File configuration and injected contexts needed an explicit incompatibility
   rule so that no trust or verification setting would be silently ignored.

The certificate identity resolver was already portable. It receives the
decoded certificate mapping exposed by an established verified TLS connection.
It does not receive a path, open files, or depend on a Paqto-owned certificate
shape. That contract was retained.

## Final API

### High-level configuration

`TlsConfig` remains the convenient and backward-compatible route. Existing
constructor fields and their positional order are preserved. It still accepts
`certfile`, `keyfile`, and optional `cafile`, and now also accepts optional
`cadata: str | bytes`.

`cadata` is passed directly to the standard library for PEM/DER trust loading.
If `cafile` and `cadata` are both supplied, the sources are additive. If
neither is supplied, Python's default trust configuration is used for the
relevant purpose.

### Advanced configuration

`TlsContextConfig` accepts:

- one caller-prepared client `ssl.SSLContext`;
- one caller-prepared server `ssl.SSLContext`;
- the generic optional peer identity resolver;
- the TLS handshake timeout.

`LanTransport(tls_contexts=...)` adopts these caller-owned contexts unchanged.
Client verification and hostname policy are derived from the client context;
incoming client-certificate policy is derived from the server context. The
endpoint host is passed as `server_hostname` for TLS/SNI, while the context
decides whether it is verified.

One transport can both connect and listen, so the advanced configuration
requires both contexts. Partial merging with high-level file configuration is
not supported.

### Ambiguity rule

`tls=...` and `tls_contexts=...` are mutually exclusive. Supplying both raises
`ValueError`. There is no implicit precedence or silent merge.

## Trust strategy

The final API supports three generic strategies:

1. Python/default trust: high-level `TlsConfig` with no `cafile` or `cadata`,
   or a caller-created default context.
2. Custom trust: high-level `cafile`, in-memory `cadata`, or both.
3. Fully custom policy: caller-prepared client/server contexts injected through
   `TlsContextConfig`.

The host owns certificate issuance, acquisition, private-key protection,
rotation, revocation, trust-anchor selection, and any interaction with its
credential storage. Paqto owns correct use of the supplied TLS capability,
handshake integration, error normalization, generic security metadata,
identity resolver invocation after verification, and lifecycle cleanup.

## Standard-library limitations and secret handling

Paqto does not accept private-key bytes and does not write them automatically
to a temporary directory. The high-level route retains accessible paths for
certificate/private-key chains because that is the interface exposed by
`SSLContext.load_cert_chain()`. A host with another storage model must prepare
the context through mechanisms appropriate to that environment and inject it.

Injected contexts are not mutated, reloaded, cloned, or destroyed by Paqto.
Stopping a transport releases Paqto's references and closes owned listeners and
connections; the caller remains the context owner. Context mutation during use
is outside Paqto's synchronization contract and should be avoided.

## Runtime changes

- Added `TlsConfig.cadata` with validation and client/server trust loading.
- Added and exported `TlsContextConfig`.
- Added the mutually exclusive `LanTransport.tls_contexts` route.
- Unified TLS policy lookup across high-level and advanced modes.
- Passed endpoint names for TLS/SNI independently of whether the context checks
  hostnames.
- Correctly treats a verified certificate supplied under server-side
  `CERT_OPTIONAL` as authenticated while allowing certificate absence; mTLS
  `CERT_REQUIRED` behavior remains strict.
- Preserved the transport stop/restart ownership model and existing path-based
  API.

## Tests

New regression coverage verifies:

- exact caller-prepared client and server context injection;
- real framed data over injected TLS contexts;
- mTLS and logical identity resolution in advanced mode;
- CA trust loaded from in-memory PEM data without a CA path;
- invalid trust rejection with a custom client context;
- file and injected modes rejected when combined;
- wrong client/server context roles rejected;
- invalid or empty CA data rejected;
- old positional `TlsConfig` argument order retained;
- injected-context lifecycle and close behavior.

Existing portable fixture tests continue to verify high-level file
configuration, mTLS, identity binding into READY sessions, hostname mismatch,
untrusted chains, missing client certificates, handshake timeout, and
connection/listener shutdown. The fixtures are local loopback credentials and
do not use the machine's certificate store.

Validation after implementation:

- focused TLS module: `20 passed`;
- final full suite: `162 passed in 2.80s`;
- final development-mode full suite with warnings as errors: `162 passed in
  3.05s`;
- Ruff: passed;
- mypy: no issues in 27 source files;
- compileall for source, tests, and examples: passed;
- `pip check`: no broken requirements;
- runnable two-node example: passed;
- Python 3.10 grammar parse for 45 source/test/example files: passed;
- public `TlsConfig` / `TlsContextConfig` import check: passed;
- documentation link check: passed;
- `git diff --check`: passed with line-ending conversion warnings only.

## Breaking changes

None intended. Existing `TlsConfig` construction, including prior positional
argument order, and `LanTransport(tls=...)` behavior remain supported.
`TlsContextConfig` and `tls_contexts` are additive. The endpoint host is now
also supplied for SNI when hostname verification is disabled; certificate
verification semantics remain controlled by the context.

## Remaining risks and roadmap

- Default trust-store composition and OpenSSL/TLS backend behavior still need a
  real supported-runtime matrix.
- Injected context behavior should be validated on runtimes whose Python TLS
  integration differs from this host.
- Hardware-backed or non-exportable keys are supported only insofar as the host
  can produce a compatible `ssl.SSLContext`; Paqto intentionally adds no
  proprietary key API.
- Hot rotation and coordinated context reload are not implemented. A future
  design should remain capability-oriented and define ownership/concurrency
  explicitly.
- Revocation policy, pinning, expiry monitoring, credential prompting, and
  secure storage remain host/deployment responsibilities.
- UDP discovery remains unauthenticated; TLS identity binding limits endpoint
  impersonation but not discovery redirection or availability attacks.
