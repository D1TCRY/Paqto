# LAN TLS Security Layer

## Phase objective

Add a generic security layer to Paqto's LAN transport using the standard Python
TLS implementation, while keeping the core transport-agnostic and
domain-agnostic. The phase covers encrypted TCP streams, configurable trust,
server certificate verification, optional mutual TLS, generic connection
security metadata, and an optional outgoing binding between a discovery claim
and an authenticated peer identity.

No request/reply, reconnect, application protocol handshake, UDP announcement
encryption, or application-domain behavior was added.

## Initial state and baseline

- The repository and every current development log were reread before changes.
- The code in the worktree, including the uncommitted foundation phase, was
  treated as the source of truth.
- Git branch: main, tracking origin/main.
- The worktree already contained all uncommitted foundation-phase changes and a
  pre-existing user modification to .gitignore. This phase did not modify or
  revert .gitignore.
- docs/development_logs remains ignored by the retained
  docs/development_logs/ rule. Historical logs were not modified or removed.
- Python version: 3.14.6.
- Baseline command: python -m pytest -q.
- Baseline result: 44 passed in 0.15s.

## Files analyzed

The audit reread:

- README.md, pyproject.toml, .gitignore, examples/lan_two_nodes.py, and package
  metadata;
- every Python module under src/paqto/core and src/paqto/lan, including the
  compatibility module src/paqto/connection.py;
- every test under tests/core, tests/lan, and tests/integration;
- all four pre-existing development logs.

The design trace covered PaqtoNode, PaqtoConfig, ConnectionManager, Transport,
Listener, Connection, SecurityInfo, LanTransport, TcpListener, TcpConnection,
LanDiscovery, public exports, exception normalization, and shutdown ordering.

## Threat model addressed

The phase addresses an active network participant that can observe, alter,
inject, or redirect LAN TCP traffic. With correct trust configuration, TLS
provides:

- confidentiality and integrity for TCP bytes after the TLS handshake;
- authentication of the outgoing connection's server certificate;
- hostname or IP-address verification by default for outgoing connections;
- optional authentication of client certificates on incoming connections;
- a verified certificate input from which deployments may derive a logical
  authenticated peer identity.

TLS does not protect:

- IPv4 UDP discovery announcements, which remain observable, spoofable, and
  subject to injection;
- availability, connection flooding, discovery flooding, or other denial of
  service;
- a private key or CA that has been compromised;
- certificate issuance, provisioning, rotation, revocation policy, or secure
  storage outside Paqto;
- application-message semantics, authorization, message sender fields,
  request/reply correlation, or application-level replay across sessions;
- identity binding for an incoming connection before a future protocol
  handshake declares which logical peer is using it.

A discovery claim is always treated as an untrusted routing hint. It is never
copied into SecurityInfo.authenticated_peer_id.

## Architectural choice

TLS is configured on LanTransport through an optional TlsConfig rather than
introducing TlsLanTransport or a wrapper.

This matches the real architecture because TLS changes how the existing TCP
stream is established but does not change LAN addressing, byte framing,
listener ownership, discovery, serialization, or the core Transport contract.
It also preserves one lifecycle implementation and avoids duplicated plain/TLS
connection code.

LanTransport() remains plain TCP. LanTransport(tls=TlsConfig(...)) creates
client and server SSL contexts during transport startup and supplies them to
asyncio.open_connection and asyncio.start_server. No cryptographic primitive is
implemented by Paqto; all TLS and X.509 verification is delegated to Python's
ssl module and its OpenSSL backend.

## Security defaults and identity model

TlsConfig requires a node certificate and private-key path. It supports an
optional CA file; when omitted, Python's system trust roots are used.

When TLS is enabled:

- outgoing certificate verification defaults to enabled;
- outgoing hostname/IP verification defaults to enabled;
- TLS 1.2 is the minimum version;
- disabling peer verification is explicit and also requires explicitly setting
  check_hostname to false;
- incoming connections are encrypted but do not claim client authentication
  unless require_client_certificate is true;
- require_client_certificate enables CERT_REQUIRED and validates the client
  certificate against configured or system trust roots.

An optional peer_identity_resolver receives only the decoded mapping of an
already verified certificate. If verification is disabled, the resolver is not
called and the connection reports authenticated=false. Paqto does not impose a
certificate subject, SAN, URI, or OID convention.

TcpConnection stores an immutable SecurityInfo snapshot. TLS connections report
encrypted=true, mechanism=tls, TLS version, cipher, certificate presence, and
the verified server name when applicable. authenticated is true only when the
relevant certificate verification policy actually succeeded.

PaqtoConfig.require_authenticated_peer_id_match is a transport-neutral,
opt-in policy for outgoing node connections. When enabled, PaqtoNode compares
the authenticated_peer_id from Connection.security_info with the Peer.id
claimed by discovery. Missing authentication, missing resolved identity, and
identity mismatch are rejected; the cached connection is closed and removed.

## Public API introduced

LAN adapter:

- paqto.lan.TlsConfig;
- paqto.lan.TlsPeerIdentityResolver;
- LanTransport(..., tls: TlsConfig | None = None);
- optional TLS arguments on TcpListener and optional SecurityInfo on
  TcpConnection, preserving direct-construction compatibility.

Core:

- PaqtoConfig.require_authenticated_peer_id_match;
- PeerAuthenticationError;
- PeerIdentityMismatchError.

The two exceptions are exported by both paqto and paqto.core.

## Compatibility

- Existing LanTransport() callers continue to use plain TCP.
- Existing TcpListener and TcpConnection constructor calls remain valid because
  all new parameters are optional.
- Existing LAN endpoints keep transport=lan and tcp:// addresses.
- TLS selection is local, explicit configuration; peers configured with
  incompatible plain/TLS modes will fail to communicate rather than silently
  downgrade.
- Deployments enabling authenticated peer-id matching must supply a resolver
  whose result exactly matches their Paqto Peer.id convention.

## Files changed in this phase

Runtime and API:

- README.md;
- src/paqto.egg-info/SOURCES.txt;
- src/paqto/__init__.py;
- src/paqto/core/__init__.py;
- src/paqto/core/config.py;
- src/paqto/core/errors.py;
- src/paqto/core/node.py;
- src/paqto/lan/__init__.py;
- src/paqto/lan/connection.py;
- src/paqto/lan/listener.py;
- src/paqto/lan/transport.py;
- src/paqto/lan/security.py (new).

Tests and offline fixtures:

- tests/lan/test_tls.py (new);
- tests/certificates/README.md;
- tests/certificates/ca.pem;
- tests/certificates/node-a.pem and node-a-key.pem;
- tests/certificates/node-b.pem and node-b-key.pem;
- tests/certificates/untrusted.pem and untrusted-key.pem.

All certificate and key files are test-only loopback fixtures. They are not
production credentials and no private-key content is reproduced in this log.
No runtime dependency was added.

## Tests added

The TLS test module verifies:

- a trusted TLS connection with hostname/IP verification;
- actual framed data in both directions over TLS;
- SecurityInfo for verified TLS and encrypted-but-not-client-authenticated TLS;
- rejection of a server certificate signed by an untrusted CA;
- correct mutual TLS and logical identities on both sides;
- rejection of a client with no certificate when the server requires one;
- startup rollback and TransportError normalization for missing TLS material;
- explicit validation required to disable verification;
- rejection and cleanup when discovery claims peer X but the verified
  certificate resolver proves peer Y;
- bounded, correct shutdown of TLS listeners, connections, and transports.

The pre-existing non-TLS tests remain enabled and passing.

## Validation commands and results

- python -m pytest -q before this phase:
  - 44 passed in 0.15s.
- python -m pytest tests\lan\test_tls.py -q:
  - 7 passed in 0.32s.
- python -m pytest -q after implementation:
  - final run: 51 passed in 0.43s.
- python -m mypy src:
  - Success: no issues found in 25 source files.
- python -m ruff check src tests examples:
  - no new findings;
  - the only two findings are the previously documented PYI034 suggestions for
    Connection.__aenter__ and Listener.__aenter__, retained for Python 3.10
    compatibility without adding typing_extensions.
- python -m ruff check src tests examples --ignore PYI034:
  - passed: All checks passed.
- python -m compileall -q src tests examples:
  - passed.
- installed-package import check for paqto, paqto.lan, TlsConfig,
  SecurityInfo, and PeerIdentityMismatchError:
  - passed; printed import-ok lan False TlsConfig PeerIdentityMismatchError.
- python -m pip check:
  - passed; no broken requirements.
- python examples\lan_two_nodes.py:
  - passed; the existing plain-LAN example discovered a peer and exchanged its
    message.
- git diff --check:
  - passed; only Windows LF/CRLF conversion warnings were emitted.
- application-domain vocabulary scan over src, tests, README, and examples:
  - no matches.

## Problems intentionally left open

- UDP discovery remains unauthenticated and unencrypted. TLS prevents a spoofed
  endpoint from successfully impersonating an untrusted certificate identity,
  but discovery spoofing can still redirect traffic, cause connection failures,
  or consume resources.
- TLS configuration currently uses one node certificate/key pair for both
  outgoing and incoming roles and one CA file plus system-store fallback. More
  elaborate trust-store composition is not included.
- Certificate provisioning, encrypted-key password callbacks, rotation,
  revocation checking, pinning, and reload without transport restart are not
  managed by Paqto in this phase.
- The optional peer-id match is enforceable only for outgoing connections,
  because discovery supplies the expected identity before connect. Incoming
  connections do not yet have a protocol-level claimed peer identity.
- TLS shutdown behavior ultimately depends on asyncio and the platform OpenSSL
  backend. Cleanup is bounded in tests, but configurable handshake/shutdown
  timeouts were not added because Paqto still declares Python 3.10 support.
- The existing lifecycle and supervision limitations documented in the
  foundation log remain, including background reader errors not being exposed
  through a public event API.
- No cross-platform or multi-version CI was available; validation ran on
  Windows with Python 3.14.6.

## Requirements for the future protocol handshake

The next protocol-handshake phase should:

1. declare the logical peer identity on each established connection;
2. compare that claim with SecurityInfo.authenticated_peer_id when an
   authenticated identity is available or required;
3. reject and close incoming connections on missing identity, mismatch, or
   policy failure before dispatching application messages;
4. bind subsequent message sender semantics to the accepted connection identity
   instead of trusting serialized sender fields;
5. negotiate protocol version and capabilities without weakening transport
   security;
6. define timeouts, cancellation, failure reporting, duplicate connections, and
   reconnect interaction;
7. decide whether freshness or application-level replay protection is needed
   beyond TLS session guarantees.

The handshake must consume generic SecurityInfo and must not move X.509 parsing
or TLS-specific policy into PaqtoNode.
