# Paqto Protocol Handshake and READY Sessions

## Phase objective

Introduce a small, generic Paqto application-protocol handshake above every
`Connection`, so an established transport stream (with or without transport
security) is not automatically accepted as a Paqto application session.

The implementation remains transport-agnostic and domain-agnostic. It adds no
application roles or domain vocabulary, does not alter TLS/X.509 parsing, and
does not implement cryptography.

## Initial state

- The worktree contained the uncommitted foundation and LAN TLS phases plus a
  pre-existing user change to `.gitignore`; all were preserved as the source of
  truth.
- `.gitignore` still ignores `docs/development_logs/`. This phase did not change
  that policy and did not modify or remove historical logs.
- The two latest logs, the full current diff/status, runtime modules, tests,
  README, project configuration, example, TLS adapter, and certificate-fixture
  policy were reviewed before editing.
- Baseline command: `python -m pytest -q`.
- Baseline result: `51 passed in 0.40s`.
- Before this phase, `ConnectionManager` cached a transport connection
  immediately and `PaqtoNode` started deserializing its frames as application
  messages without a protocol readiness boundary.

## Files analyzed

The review traced the current implementations and tests for:

- `PaqtoNode`, `PaqtoConfig`, `ConnectionManager`, `Connection`, `Listener`,
  `Transport`, `Message`, `Serializer`, `MessageRouter`, discovery and endpoint
  selection;
- `LanTransport`, `TcpConnection`, `TcpListener`, `TlsConfig`, TLS security
  metadata and peer identity resolution;
- all current core, LAN, TLS, integration, lifecycle, and cleanup tests;
- `README.md`, `pyproject.toml`, `examples/lan_two_nodes.py`, package exports,
  generated source metadata, and every development log.

## Protocol lifecycle

The node lifecycle is now:

```text
transport connection
    -> optional transport security handshake
    -> Paqto protocol hello exchange
    -> identity and compatibility validation
    -> READY ProtocolSession
    -> application frame deserialization and dispatch
```

Incoming transport accepts immediately create a bounded handshake task, rather
than blocking the listener accept loop. Outgoing connections run the handshake
as a `ConnectionManager` preparation step. The manager caches the connection
only after preparation succeeds. Failed or cancelled preparation closes the
connection and never exposes it as reusable.

No application serializer or handler is invoked before READY. Reader tasks are
started for outgoing connections only after a session exists; an incoming task
performs the handshake first and enters the application reader only on success.

## Frame and handshake format

The existing transport frame boundary is unchanged. Paqto uses the first byte
inside each transport frame as a protocol kind:

- `0x00`: protocol/control frame;
- `0x01`: serialized application message.

Control and application frames are therefore unambiguous without changing the
TCP four-byte length prefix or the abstract `Connection` API. Control frames do
not reach `Serializer` or `MessageRouter`. Version 1 rejects unexpected control
frames after READY; this leaves room for deliberately specified future control
messages rather than silently dispatching them.

The version 1 hello control payload is compact UTF-8 JSON with:

- `magic`: fixed protocol identifier `PAQTO`;
- `type`: `hello`;
- `version`: exact Paqto protocol version;
- `peer_id`: logical identity declared by the peer;
- `capabilities`: generic string capabilities;
- `serializer`: stable application encoding identifier;
- `max_message_size`: maximum serialized application payload accepted;
- `metadata`: optional JSON protocol metadata.

JSON is fixed only for the small hello control message and does not replace the
application serializer. Hello payloads are bounded to 64 KiB. Capabilities are
negotiated as the intersection of local and remote values, preserving local
preference order. The negotiated message size is the lower of the two limits.
Serializer identifiers must match exactly.

## Protocol version

- Introduced `PROTOCOL_VERSION = 1` and `PROTOCOL_MAGIC = "PAQTO"`.
- Version negotiation is intentionally exact in this first format.
- An incompatible version raises `ProtocolVersionError` with both local and
  remote values, closes the connection, and never creates a session.
- The explicit version field and specific exception allow a future phase to add
  a supported-version set or compatibility range without conflating version
  errors with socket failures.

## Identity binding

Three values remain deliberately distinct:

1. discovery peer id: untrusted intended destination/reachability hint;
2. handshake peer id: logical identity declared for this protocol session;
3. authenticated peer id: identity proved by the transport security mechanism.

For outgoing connections, the handshake id must equal the intended discovered
peer id; otherwise the connection is rejected rather than sending data to an
unexpected endpoint. This consistency check does not make discovery trusted.

Whenever `Connection.security_info.authenticated_peer_id` is available, it must
equal the handshake peer id on both outgoing and incoming connections. A
mismatch raises `PeerIdentityMismatchError`, closes the connection, and leaves
no manager cache or READY session. `require_authenticated_peer_id_match=True`
now makes authenticated identity plus resolved peer id mandatory for every
session accepted by that node.

`ProtocolSession.peer_id_authenticated` records whether the accepted handshake
identity was actually authenticated. On plain TCP, a valid hello creates a
session with `peer_id_authenticated=False`: the id identifies the session but is
not cryptographic proof of the remote party.

Application `Message.sender` is checked against the READY session peer id, and
a non-null recipient must equal the local node id. Serialized envelope identity
fields can no longer contradict the connection-bound session identity.

## API introduced or changed

- New `paqto.core.protocol` module.
- Public constants: `PROTOCOL_MAGIC`, `PROTOCOL_VERSION`.
- Public immutable models: `HandshakeOffer`, `ProtocolSession`.
- `Serializer.protocol_id` supplies a default Python class-based encoding id;
  deployments can override it or set `PaqtoConfig.serializer_id`.
- New `PaqtoConfig` options:
  - `handshake_timeout`;
  - `protocol_version`;
  - `capabilities`;
  - `serializer_id`;
  - `max_message_size`;
  - `protocol_metadata`.
- `PaqtoNode.session_for(connection)` reports negotiated READY session data.
- `ConnectionManager.connect(..., prepare=...)` runs an async preparation step
  before caching a new connection.
- New errors in the `PaqtoError` hierarchy:
  - `ProtocolError`;
  - `ProtocolHandshakeError`;
  - `ProtocolVersionError`;
  - `ProtocolFrameError`;
  - `ProtocolHandshakeTimeoutError` (also a `PaqtoTimeoutError`).

## Error handling and cleanup

- Malformed JSON, wrong magic/type, invalid field types, duplicate capabilities,
  oversized control data, incompatible encodings, and early application frames
  fail before READY.
- Handshake timeout has its own validated configuration and specific exception.
- A remote transport close during negotiation is normalized to
  `ProtocolHandshakeError` with the original close error preserved as cause.
- All handshake failures and cancellation close the underlying connection.
- Failed outgoing preparation is not cached by `ConnectionManager`.
- Incoming failure removes the connection and any partial session state.
- Application control frames, identity contradictions, and size violations close
  the reader connection and never reach handlers.

## Compatibility decisions

- `Connection`, `Transport`, LAN TCP framing, TLS configuration, and discovery
  datagrams are unchanged. Direct transport users can continue exchanging raw
  byte frames.
- `PaqtoNode` peers now require the Paqto version 1 handshake. This is an
  intentional wire-protocol incompatibility with older nodes that sent a
  serialized `Message` as their first frame; accepting both formats would allow
  application data to bypass READY.
- Plain non-TLS nodes remain supported, but their session identity is explicitly
  unauthenticated.
- The application serializer still owns the complete `Message` envelope.
- The default serializer id is convenient for the same Python serializer class.
  Stable cross-language or dynamically generated encodings should configure an
  explicit id.
- Discovery remains unauthenticated and is neither a trust store nor an
  authorization database.

## Files modified in this phase

Runtime/API:

- `src/paqto/core/protocol.py` (new);
- `src/paqto/core/node.py`;
- `src/paqto/core/manager.py`;
- `src/paqto/core/config.py`;
- `src/paqto/core/serializer.py`;
- `src/paqto/core/errors.py`;
- `src/paqto/core/__init__.py`;
- `src/paqto/__init__.py`;
- `src/paqto.egg-info/SOURCES.txt`.

Tests:

- `tests/core/test_protocol.py` (new);
- `tests/core/test_connection_manager.py`;
- `tests/integration/test_lan_nodes.py`;
- `tests/lan/test_tls.py`.

Documentation:

- `README.md`;
- `pyproject.toml` (explicit pytest-asyncio fixture loop scope);
- `docs/development_logs/2026-08-18_03-protocol-handshake.md` (this ignored
  file).

`.gitignore` was not modified by this phase.

## Tests added or extended

Coverage now includes:

- valid hello and negotiated READY properties;
- explicit incompatible-version errors at helper and real-node level;
- discovery/hello mismatch and TLS-authenticated/hello mismatch;
- malformed hello JSON;
- handshake timeout;
- remote close during handshake;
- application/control frame separation and size enforcement;
- proof that an application frame sent before hello is never dispatched;
- normal plain-LAN send/receive after READY;
- explicit unauthenticated session status on plain TCP;
- mutual TLS plus handshake with authenticated READY sessions on both ends;
- failed manager preparation being closed and never cached;
- positive finite handshake-timeout validation;
- clean shutdown with empty reader-task/session registries.

## Validation commands and results

- Baseline `python -m pytest -q`:
  - `51 passed in 0.40s`.
- Intermediate full suite after implementation and tests:
  - `67 passed in 0.55s`.
- `python -m mypy src`:
  - `Success: no issues found in 26 source files`.
- `python -m ruff check src tests examples --ignore PYI034` initially found only
  deterministic import/export ordering in the new public API; Ruff's mechanical
  fix was applied. Final validation is recorded below after all documentation
  and review work.
- The first `python -X dev -m pytest -q -W error` run passed all 67 tests but
  exposed pytest-asyncio's deprecation warning for an implicit fixture loop
  scope. `asyncio_default_fixture_loop_scope = "function"` was added explicitly;
  the warning was unrelated to runtime code but would otherwise make future test
  behavior dependent on a plugin default change.
- Final `python -X dev -m pytest -q -W error`:
  - latest run: `67 passed in 0.54s`;
  - no `ResourceWarning`, pending-task warning, unclosed-stream warning, or
    unclosed-socket warning was emitted.
- Final `python -m pytest -q`:
  - `67 passed in 0.53s`.
- Final `python -m mypy src`:
  - `Success: no issues found in 26 source files`.
- Final `python -m ruff check src tests examples --ignore PYI034`:
  - `All checks passed!`.
- Raw `python -m ruff check src tests examples`:
  - only the same two pre-existing `PYI034` suggestions remain on
    `Connection.__aenter__` and `Listener.__aenter__`; they are retained because
    the package supports Python 3.10 without `typing_extensions`.
- `python -m compileall -q src tests examples`:
  - passed.
- Public import check for the Paqto magic/version, protocol session/error types,
  and LAN TLS configuration:
  - passed; printed `import-ok PAQTO 1 ProtocolSession ProtocolVersionError
    TlsConfig`.
- `python -m pip check`:
  - passed; no broken requirements.
- `python examples\\lan_two_nodes.py`:
  - passed; two plain-LAN nodes completed the new handshake and exchanged the
    greeting.
- `git diff --check`:
  - passed with only Windows line-ending conversion warnings.
- `git check-ignore -v` for this log:
  - confirmed the existing `.gitignore` rule at line 2.
- Scan of source, tests, README, and examples for prohibited application-domain
  vocabulary:
  - no matches.

## Problems intentionally left open

- Version 1 supports one exact protocol version and one exact serializer id; a
  future compatibility policy may negotiate version ranges or multiple
  encodings.
- Capabilities are opaque strings. Their semantics and dependencies belong to
  the features that define them; Paqto does not add a generic dependency solver.
- There is no authorization policy beyond optional authenticated identity
  binding. Authentication answers who the peer is, not what it may do.
- Discovery UDP remains spoofable and unauthenticated. A spoof can redirect or
  consume connection attempts, but cannot bypass hello/security identity checks.
- Protocol v1 adds no nonce, transcript signature, or application replay scheme.
  TLS supplies in-session channel integrity when enabled; plain transports do
  not. No proprietary cryptography was added.
- Request/reply, delivery acknowledgement, reconnect, duplicate simultaneous
  connection resolution, session resumption, and error reporting/supervision
  remain separate future work.
- Background connection-task failures are consumed to prevent unhandled task
  warnings but still lack a public node error-event API.
- Incoming handshakes run concurrently and are time-bounded, but version 1 does
  not yet expose a configurable limit on the number of simultaneous pending
  handshakes. Deployments still need transport/network-level connection limits
  for resource-exhaustion resistance.
- `ConnectionManager` still serializes all new outgoing connection preparation,
  not just preparation for the same peer.
- The negotiated application limit is protocol-level. A concrete transport may
  impose a lower frame limit and will still enforce it independently.
- No cross-platform or multi-version CI was available; validation was performed
  on Windows with Python 3.14.6.

## Guidance for the next phase

1. Keep future control frames explicitly typed and handled before the serializer;
   do not overload application `Message.type` for protocol machinery.
2. Add a public supervision/error event before reconnect or background retry so
   terminal session failures are observable.
3. Define simultaneous inbound/outbound duplicate-session selection before
   reconnect, including which authenticated session wins and how losing sessions
   close.
4. If multiple protocol versions or encodings are needed, negotiate from explicit
   supported sets while retaining bounded hello parsing and downgrade rules.
5. Build request/reply on READY sessions and bind correlation/sender semantics to
   `ProtocolSession.peer_id` rather than trusting serialized identity fields.
6. Decide delivery, replay, retry, and idempotency semantics independently of
   discovery and transport security.
