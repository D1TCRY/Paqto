# Python docstring review

Date: 2026-08-18  
Scope: systematic docstring review of the current `src/paqto/` package

## Objective

Improve IDE and `help()` guidance for the current implementation without
duplicating the architectural Markdown documentation or changing behavior.
Implementation and verified tests remained the source of truth.

No commit or push was performed.

## Initial repository state

The working tree already contained the implementation, hardening, audit, and
developer-documentation changes from earlier phases. Those changes were
preserved. This phase modified only Python docstrings under `src/paqto/` and
created this log.

Baseline checks before source edits:

```text
python -m pytest
148 passed in 2.35s

python -m ruff check src tests examples
All checks passed!

python -m mypy src
Success: no issues found in 27 source files

python -m compileall -q src tests examples
passed
```

## Modules reviewed

All 27 Python source modules were inspected:

- package surface: `paqto.__init__`, `paqto.connection`;
- core: `__init__`, `config`, `connection`, `discovered`, `discovery`,
  `endpoint`, `errors`, `events`, `listener`, `manager`, `message`, `node`,
  `peer`, `protocol`, `router`, `security`, `serializer`, and `transport`;
- LAN: `__init__`, `address`, `connection`, `discovery`, `listener`,
  `security`, and `transport`.

The public Markdown documentation, latest independent audit, latest developer
documentation log, package exports, example, and relevant tests were also
reviewed before wording source guarantees.

## Coverage checklist

### Public classes and models

Reviewed and documented the node and configuration types; peer, endpoint,
discovery, message, event, security, handshake, session, ACK, and heartbeat
models; routing and connection managers; enums and policies; the complete
public exception hierarchy; and all LAN transport, discovery, listener,
connection, address, and TLS types.

Configuration and dataclass docstrings now explain non-obvious fields,
including seconds, byte limits, queue and pending-operation counts, peer TTL,
reconnect delays, heartbeat, TLS verification, authenticated identity mapping,
and strict peer-id binding.

### Abstract contracts

Reviewed `Connection`, `Listener`, `Transport`, `DiscoveryService`, and
`Serializer`, including lifecycle ownership, complete-frame expectations,
timeouts, cleanup cooperation, serializer responsibility, and the absence of
implicit authentication or application delivery guarantees.

### Public functions and methods

Reviewed every public function and method. An AST coverage check reports zero
undocumented public classes, functions, or public methods. Important additions
cover `PaqtoNode.start`, `stop`, `discover`, `connect`, `send`, `request`,
`reply`, handler registration, connection-manager operations, message/event
routing, peer creation, protocol negotiation, LAN address helpers, and LAN
adapter lifecycle methods.

### Important private helpers

Documented 62 non-public helpers or support types whose role is materially
useful during maintenance. These include:

- protocol hello/control encoding, bounded JSON validation, and failed-handshake
  cleanup;
- outgoing/incoming session preparation and deterministic duplicate-connection
  selection;
- exact-connection request, reply, ACK, and heartbeat correlation;
- reconnect scheduling and session recreation;
- bounded inbound/outbound queues and worker ownership;
- READY-session registration and deactivation;
- message envelope and session identity validation;
- untrusted discovery parsing, cache admission, and expiry;
- TLS security metadata and authenticated certificate-to-peer-id mapping;
- TCP framing, payload timeout normalization, listener admission, and advertised
  endpoint construction.

Trivial validators, obvious constructors, context-manager plumbing, and simple
task bookkeeping were not forced to carry docstrings.

## Files changed

Docstrings were added or improved in 23 modules:

- `src/paqto/core/config.py`
- `src/paqto/core/connection.py`
- `src/paqto/core/discovered.py`
- `src/paqto/core/discovery.py`
- `src/paqto/core/endpoint.py`
- `src/paqto/core/errors.py`
- `src/paqto/core/events.py`
- `src/paqto/core/listener.py`
- `src/paqto/core/manager.py`
- `src/paqto/core/message.py`
- `src/paqto/core/node.py`
- `src/paqto/core/peer.py`
- `src/paqto/core/protocol.py`
- `src/paqto/core/router.py`
- `src/paqto/core/security.py`
- `src/paqto/core/serializer.py`
- `src/paqto/core/transport.py`
- `src/paqto/lan/address.py`
- `src/paqto/lan/connection.py`
- `src/paqto/lan/discovery.py`
- `src/paqto/lan/listener.py`
- `src/paqto/lan/security.py`
- `src/paqto/lan/transport.py`

Approximately 145 class, function, method, and important-helper docstrings were
added or materially improved, in addition to short module docstrings.

The existing docstrings in `paqto.__init__`, `paqto.connection`,
`paqto.core.__init__`, and `paqto.lan.__init__` were already sufficient and were
left unchanged.

## Important semantic wording

- `Peer` and `DiscoveredPeer` describe declared, untrusted identity claims;
  only transport security plus identity mapping can expose an authenticated id.
- `SecurityInfo.authenticated=True` does not necessarily mean that
  `authenticated_peer_id` was resolved.
- Strict peer-id matching requires authenticated identity to exist and agree
  with the hello declaration.
- Technical ACK wording now states that receipt, deserialization, and envelope
  validation may precede dispatch admission and do not prove handler execution,
  durability, or application success.
- Local writer completion is not described as remote receipt.
- Request/reply is described as volatile, exact-connection, in-memory
  correlation with cleanup on timeout, cancellation, disconnect, and shutdown.
- Reconnect is described as creation of a new security/protocol session, not
  retransmission or restoration of old pending operations.
- Queue capacities are described as item counts, not aggregate byte or caller
  task limits.
- The advertised-host docstring was corrected to include the actual hostname
  resolution fallback between primary-address detection and bind-host fallback.

No misleading existing claim required a runtime change.

## Runtime and type changes

None. No executable statement, signature, annotation, public API, test, or
configuration value was changed. No type correction was necessary.

During final validation, adding docstrings to two no-op private asyncio UDP
callbacks caused Ruff `RET501` to begin inspecting their pre-existing explicit
`return None` statements. The unnecessary callback docstrings were removed
instead of modifying runtime statements.

## Validation commands and results

Final checks:

```text
python -m pytest
148 passed in 2.48s

python -m ruff check src tests examples
All checks passed!

python -m mypy src
Success: no issues found in 27 source files

python -m compileall -q src tests examples
passed
```

Additional checks:

- parsed every source module with `ast.parse(..., feature_version=(3, 10))`;
  all 27 passed Python 3.10 grammar validation;
- AST-inspected every public top-level class/function and every public method;
  zero lacked a docstring;
- used `inspect.getdoc()` on `PaqtoNode`, its lifecycle and messaging methods,
  `PaqtoConfig`, core contracts, security/protocol models, protocol negotiation,
  and LAN/TLS classes; all returned useful English documentation;
- searched source wording for exactly-once, guaranteed-delivery, secure-default,
  discovery-authentication, ACK/application-success, and reconnect/retransmission
  overclaims; matches were accurate distinctions or explicit non-guarantees;
- searched source for private-key blocks and test private-key filenames; none
  were present;
- `git diff --check` passed, with only the repository's existing Windows
  LF-to-CRLF warnings;
- checked final `git status`; all unrelated pre-existing changes remain.

## Remaining gaps

- Validation used Python 3.14.6. Python 3.10 grammar was checked, but a real
  Python 3.10 runtime/CI job remains necessary for full lower-bound validation.
- Private helpers that merely validate a scalar, forward a callback, expose a
  simple property, or perform obvious task bookkeeping intentionally remain
  without docstrings.
- Concrete third-party adapters may impose additional lifecycle and security
  rules beyond the generic abstract contracts and must document those rules in
  their own implementations.
