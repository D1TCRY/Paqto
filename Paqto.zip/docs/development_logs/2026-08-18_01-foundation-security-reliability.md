# Foundation Audit, Security Metadata, and Lifecycle Hardening

## Phase objective

Prepare Paqto for later security and reliability work without implementing TLS,
request/reply, or reconnect. The phase audited the real repository, removed API
ambiguity, introduced transport-neutral connection security metadata, and fixed
only lifecycle, race, resource-cleanup, and exception-boundary issues that would
make later work unsafe.

The project remains domain-neutral. No application-specific concepts were added.

## Initial state

- Git branch: `main`, aligned with `origin/main` at commit `e77af6b`.
- The worktree already contained an unrelated user modification to `.gitignore`.
  The committed file contained only `docs/development_logs/`; the user's working
  copy expanded the ignore rules while retaining that entry. This phase did not
  modify or revert `.gitignore`.
- `docs/development_logs/` existed on disk with three historical logs and was
  ignored by Git. `git check-ignore -v` confirmed the active rule. No historical
  log was deleted or modified, and the Git policy was not changed.
- The first test attempt used Python 3.14.6 without `pytest-asyncio` and produced
  `17 passed, 15 failed`; all 15 failures were async-test collection/execution
  failures caused by the missing declared dev dependency.
- After installing `pytest-asyncio>=0.23`, the valid code baseline was
  `32 passed in 0.10s`.
- A direct `python -c "import paqto"` initially failed because the local package
  was not installed, although pytest imports worked through its configured
  `pythonpath = ["src"]`.
- No Ruff or Mypy configuration was present in `pyproject.toml`. Both tools were
  available in the environment and were used as additional diagnostics.

## Files analyzed

The complete repository inventory was inspected, including ignored files:

- `README.md`, `pyproject.toml`, `.gitignore`, `LICENCE`, `build.bat`, and
  `publish.bat`;
- every module under `src/paqto/`, including all core and LAN implementations and
  the legacy `src/paqto/connection.py`;
- generated package metadata under `src/paqto.egg-info/`;
- every test under `tests/lan/` and `tests/integration/`;
- `examples/lan_two_nodes.py`;
- all three pre-existing files under `docs/development_logs/`.

The audit specifically traced `PaqtoNode`, `Transport`, `Connection`, `Listener`,
`ConnectionManager`, `Message`, `Serializer`, `MessageRouter`,
`DiscoveryService`, `LanTransport`, `TcpConnection`, `TcpListener`,
`LanDiscovery`, the exception hierarchy, and all public export paths.

## Real architecture found

- The core is an async, byte-frame, transport-neutral abstraction layer.
  `PaqtoNode` orchestrates one `Transport`, one `DiscoveryService`, one
  `Serializer`, one listener, a `ConnectionManager`, and a `MessageRouter`.
- `Message` is the application envelope, while serializers own conversion of the
  complete envelope to and from bytes.
- `ConnectionManager` caches outgoing connections by logical `Peer.id`.
- `LanTransport` is the concrete TCP transport. `TcpConnection` uses a four-byte
  big-endian length prefix and `TcpListener` accepts asyncio streams.
- `LanDiscovery` is separate from message transport and uses IPv4 UDP broadcast
  with JSON `discover` and `announce` packets.
- `src/paqto/connection.py` was not part of this architecture: it contained an
  older synchronous, threaded, reconnecting TCP implementation with a different
  `Connection` API. Consequently, `from paqto import Connection` and
  `from paqto.connection import Connection` returned unrelated classes.
- The documented LAN implementation broadly matched the code, but historical
  logs did not cover later lifecycle and concurrency behavior.

## Problems found

1. `PaqtoNode.start()` marked the node running before discovery startup finished
   and did not roll back transport/listener/discovery resources after partial
   failure. Concurrent `start()` calls could both pass the state check.
2. `PaqtoNode.stop()` could stop at the first cleanup exception, leaving later
   resources active, and could attempt to await/cancel its own reader task when
   called from a message handler.
3. Concurrent `ConnectionManager.connect()` calls for the same peer could open
   duplicate connections, overwrite the cache, and leak one connection.
4. `TcpListener.close()` woke only one pending `accept()` and left other waiters
   blocked. Connections queued but not yet returned were not closed.
5. On Python 3.14, `AbstractServer.wait_closed()` waits for accepted connections;
   waiting before closing listener-owned connections caused a shutdown deadlock.
6. Concurrent `TcpConnection.receive_frame()` calls could consume pieces of the
   same stream frame. Explicit send/receive serialization was absent.
7. Socket creation/bind failures from `LanDiscovery.start()` escaped as raw
   `OSError` instead of `DiscoveryError` and left copied local state behind.
8. Serializer and message-handler failures were not normalized through the
   existing `SerializationError` and `MessageRoutingError` hierarchy.
9. The root public API exported only `PaqtoError`, while `paqto.core` exposed the
   concrete exception hierarchy. The two intended public entry points were
   inconsistent.
10. A `Connection` had endpoint and closed state but no generic way to expose
    security guarantees without coupling the core to TLS.
11. Static typing exposed imprecise LAN types around `getaddrinfo()` and
    `asyncio.start_server()`.

## Architectural decisions

### Generic connection security metadata

Added immutable `SecurityInfo` with:

- `encrypted: bool`;
- `authenticated: bool`;
- `authenticated_peer_id: str | None`;
- `mechanism: str | None`;
- immutable copied `metadata: Mapping[str, Any]`.

`Connection.security_info` is a concrete, non-abstract property whose default is
an immutable snapshot making no security claims. Existing and future transports
therefore remain valid without TLS or any security mechanism. A transport that
does provide security can override the property with its actual guarantees.

No TLS types, certificates, cipher names, or transport-specific policies were
introduced into the core.

### Lifecycle and concurrency

- `PaqtoNode` start/stop transitions are serialized by a lifecycle lock.
- Partial node startup performs best-effort rollback while preserving the
  original startup exception.
- Node shutdown attempts every cleanup stage, ignores normal task cancellation,
  and re-raises the first actual component cleanup error after resources have
  been processed.
- `ConnectionManager` serializes connection-cache mutations and connection
  creation. This intentionally favors correctness over parallel initial
  connection establishment in this pre-alpha phase.
- `TcpConnection` uses independent send and receive locks, preserving full-duplex
  behavior while preventing same-direction stream corruption.
- `TcpListener` explicitly tracks pending accept waiters and all accepted
  connections. Closing a listener wakes every waiter, closes its connections,
  and only then awaits final server shutdown.

### API ambiguity and exceptions

- The old threaded `paqto.connection.Connection` implementation was removed.
  `paqto.connection` is now a compatibility import of the canonical async
  `paqto.core.connection.Connection`, so all public import paths resolve to the
  same type.
- The root package now exports the complete existing exception hierarchy,
  `MessageHandler`, and `SecurityInfo` consistently with `paqto.core`.
- Unexpected serializer failures and invalid serializer return types become
  `SerializationError`; unexpected handler failures become
  `MessageRoutingError`; discovery socket startup failures become
  `DiscoveryError`.
- LAN discovery constructor validation now uses `TypeError` for wrong argument
  types and retains `ValueError` for invalid values.

## Files modified

Runtime and API:

- `README.md`
- `src/paqto/__init__.py`
- `src/paqto/connection.py`
- `src/paqto/core/__init__.py`
- `src/paqto/core/connection.py`
- `src/paqto/core/manager.py`
- `src/paqto/core/node.py`
- `src/paqto/core/router.py`
- `src/paqto/core/security.py` (new)
- `src/paqto/lan/address.py`
- `src/paqto/lan/connection.py`
- `src/paqto/lan/discovery.py`
- `src/paqto/lan/listener.py`
- `src/paqto/lan/transport.py`

Packaging metadata:

- `src/paqto.egg-info/SOURCES.txt` was regenerated by the editable installation
  and now includes `src/paqto/core/security.py`.

Tests:

- `tests/core/test_connection.py` (new)
- `tests/core/test_connection_manager.py` (new)
- `tests/core/test_node_lifecycle.py` (new)
- `tests/core/test_router.py` (new)
- `tests/lan/test_lan_discovery.py`
- `tests/lan/test_lan_transport.py`
- `tests/lan/test_tcp_connection.py`
- `tests/lan/test_tcp_listener.py`

Documentation:

- `docs/development_logs/2026-08-18_01-foundation-security-reliability.md`
  (this new, ignored log).

`.gitignore` was not modified by this phase.

## Tests added or modified

New coverage verifies:

- default and custom `SecurityInfo`, immutable metadata snapshots, and consistent
  connection import paths;
- coalescing/reuse under concurrent manager connects;
- node startup rollback and concurrent-start serialization;
- normalization of message-handler errors;
- plain TCP reporting no security guarantee;
- frame boundaries under concurrent receives;
- normalization and rollback of LAN discovery socket errors;
- waking multiple pending accepts;
- cleanup of queued and already accepted listener connections;
- the Python 3.14 listener shutdown ordering that previously deadlocked.

## Validation commands and results

Baseline:

- `python --version`
  - Python 3.14.6.
- `python -m pytest -q` before installing dev requirements
  - `17 passed, 15 failed`; missing `pytest-asyncio`, not a code baseline.
- `python -m pip install "pytest-asyncio>=0.23"`
  - Passed; installed the dependency already declared by `[project.optional-dependencies].dev`.
- `python -m pytest -q` before source changes
  - Passed: `32 passed in 0.10s`.
- direct import before editable install
  - Failed with `ModuleNotFoundError: No module named 'paqto'`.

Final validation:

- `python -m pip install -e . --no-deps`
  - Passed; built and installed `paqto-0.0.1` editable.
- `python -m pytest -q`
  - Passed: `44 passed in 0.18s`.
- `python -m mypy src`
  - Passed: `Success: no issues found in 24 source files`.
- `python -m ruff check src tests examples`
  - Completed with two `PYI034` suggestions on the pre-existing `__aenter__`
    return annotations in `Connection` and `Listener`. They suggest
    `typing.Self`, which is unavailable in the declared Python 3.10 baseline
    without adding `typing_extensions`; no other Ruff findings remain.
- `python -m compileall -q src tests examples`
  - Passed.
- installed-package import check for `paqto`, `paqto.connection`, `paqto.core`,
  and `paqto.lan`, including connection identity and default security metadata
  - Passed; printed `import-ok lan`.
- `python examples\\lan_two_nodes.py`
  - Passed. The two real nodes discovered each other and exchanged the greeting.
- `git diff --check`
  - Passed; only platform line-ending warnings were emitted.

## Remaining open issues

- TLS, authentication handshakes, certificate/credential configuration,
  request/reply correlation, reconnect, retry, and delivery guarantees remain
  intentionally unimplemented.
- A node operation that races with `PaqtoNode.stop()` after its initial running
  check does not yet have a formally documented cancellation/atomicity contract.
  The fixed manager and cleanup behavior prevents the original duplicate-connect
  leak in normal node usage, but a future reliability phase should define
  in-flight operation shutdown semantics explicitly.
- Reader-task failures are consumed to avoid unhandled-task warnings but are not
  exposed through a public error callback/event API. This should be designed
  before reconnect or supervision is added.
- `ConnectionManager` currently serializes all initial connection creation, not
  only connects to the same peer. Per-peer coalescing can be added later if
  parallel connection establishment becomes important.
- `LanTransport` retains references to closed outgoing connections until stop.
- LAN discovery remains IPv4 broadcast, unauthenticated, without peer TTL or
  expiration, and with the limitations recorded in earlier logs.
- Multi-version and multi-platform CI was not available. This phase ran on
  Windows with Python 3.14.6.
- Ruff's two `typing.Self` suggestions remain for Python 3.10 compatibility.

## Risks and incompatibilities

- Code that instantiated the obsolete synchronous
  `paqto.connection.Connection(client_ip=..., ...)` will break. The package was
  at version 0.0.1 and the old type conflicted directly with the documented async
  public API; removing the ambiguity was considered necessary before adding
  security or reconnect behavior.
- `TcpListener.close()` now closes connections accepted by that listener. Callers
  must not expect such connections to remain usable after listener shutdown.
- Wrong-type LAN discovery constructor arguments now raise `TypeError` rather
  than `ValueError`.
- Message handler and serializer exceptions are now wrapped in Paqto-specific
  exceptions, with the original exception preserved as `__cause__`.
- `SecurityInfo.metadata` is read-only and copied shallowly. Nested mutable values
  remain the caller's responsibility; deep-copy semantics were intentionally not
  added.

## Guidance for the next phase

1. Define the security configuration boundary separately from `SecurityInfo`:
   configuration requests capabilities, while `security_info` reports guarantees
   of an established connection.
2. Keep TLS or other mechanisms inside concrete transports/adapters. Populate
   `SecurityInfo` only after negotiation and peer verification are complete.
3. Define how a discovered logical peer identity is bound to
   `authenticated_peer_id`; do not trust discovery metadata as authentication.
4. Specify node behavior for in-flight `discover`, `connect`, and `send` during
   shutdown before adding reconnect or retry loops.
5. Add a public supervision/error-reporting mechanism before background retries,
   so serialization, routing, and transport failures are observable.
6. Consider per-peer connection coalescing and closed-connection pruning when
   expanding connection management.
7. Preserve framing and serializer boundaries: TLS should secure the byte stream,
   not leak certificate or socket concepts into `Message`, `Serializer`, or
   `MessageRouter`.
